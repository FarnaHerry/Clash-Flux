// Glaze Library
// For the license information refer to glaze.hpp

#pragma once

#include <cctype>
#include <charconv>
#include <iterator>
#include <limits>
#include <memory>
#include <utility>
#include <vector>

#include "glaze/core/chrono.hpp"
#include "glaze/core/common.hpp"
#include "glaze/core/read.hpp"
#include "glaze/core/reflect.hpp"
#include "glaze/file/file_ops.hpp"
#include "glaze/toml/common.hpp"
#include "glaze/toml/opts.hpp"
#include "glaze/toml/skip.hpp"
#include "glaze/util/glaze_fast_float.hpp"
#include "glaze/util/nullable_traits.hpp"
#include "glaze/util/parse.hpp"
#include "glaze/util/type_traits.hpp"
#include "glaze/util/variant.hpp"

namespace glz
{
   template <>
   struct parse<TOML>
   {
      template <auto Opts, class T, is_context Ctx, class It0, class It1>
      static void op(T&& value, Ctx&& ctx, It0&& it, It1 end)
      {
         using V = std::remove_cvref_t<T>;
         from<TOML, V>::template op<Opts>(std::forward<T>(value), std::forward<Ctx>(ctx), std::forward<It0>(it), end);
      }
   };

   inline constexpr int toml_hex_to_int(const char c) noexcept
   {
      if (c >= '0' && c <= '9') return c - '0';
      if (c >= 'a' && c <= 'f') return 10 + (c - 'a');
      if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
      return -1;
   }

   template <class It, class End>
   inline bool append_toml_unicode_escape_u(std::string& out, It& it, End end) noexcept
   {
      auto hex_it = it;
      ++hex_it; // first hex digit after 'u'
      if (hex_it == end) {
         return false;
      }

      const auto* const hex_begin = &(*hex_it);
      const auto* const hex_end = hex_begin + (end - hex_it);
      const auto* cursor = hex_begin;
      char utf8[4]{};
      char* dst = utf8;

      if (handle_unicode_code_point(cursor, dst, hex_end).written == 0) {
         return false;
      }

      out.append(utf8, static_cast<size_t>(dst - utf8));
      hex_it += (cursor - hex_begin);
      --hex_it; // leave iterator on the last consumed character
      it = hex_it;
      return true;
   }

   template <class It, class End>
   inline bool append_toml_unicode_escape_U(std::string& out, It& it, End end) noexcept
   {
      auto hex_it = it;
      ++hex_it; // first hex digit after 'U'

      if ((end - hex_it) < 8) {
         return false;
      }

      uint32_t code_point{};
      for (size_t i = 0; i < 8; ++i) {
         const int digit = toml_hex_to_int(*(hex_it + i));
         if (digit < 0) {
            return false;
         }
         code_point = (code_point << 4) | static_cast<uint32_t>(digit);
      }

      if (code_point > 0x10FFFF || (code_point >= 0xD800 && code_point <= 0xDFFF)) {
         return false;
      }

      char utf8[4]{};
      const auto offset = code_point_to_utf8(code_point, utf8);
      if (!offset) {
         return false;
      }

      out.append(utf8, static_cast<size_t>(offset));
      it = hex_it + 7; // leave iterator on the last consumed character
      return true;
   }

   template <class It, class End>
   inline bool append_toml_basic_escape(std::string& out, It& it, End end) noexcept
   {
      switch (*it) {
      case '"':
         out.push_back('"');
         return true;
      case '\\':
         out.push_back('\\');
         return true;
      case 'e':
         out.push_back('\x1B');
         return true;
      case 'b':
         out.push_back('\b');
         return true;
      case 't':
         out.push_back('\t');
         return true;
      case 'n':
         out.push_back('\n');
         return true;
      case 'f':
         out.push_back('\f');
         return true;
      case 'r':
         out.push_back('\r');
         return true;
      case 'x': {
         if (it + 2 >= end) {
            return false;
         }
         const int hi = toml_hex_to_int(*(it + 1));
         const int lo = toml_hex_to_int(*(it + 2));
         if (hi < 0 || lo < 0) {
            return false;
         }
         out.push_back(static_cast<char>((hi << 4) | lo));
         it += 2;
         return true;
      }
      case 'u':
         return append_toml_unicode_escape_u(out, it, end);
      case 'U':
         return append_toml_unicode_escape_U(out, it, end);
      default:
         return false;
      }
   }

   // Parse TOML key (bare key or quoted key)
   template <class Ctx, class It, class End>
   inline bool parse_toml_key(std::string& key, Ctx& ctx, It&& it, End end) noexcept
   {
      key.clear();
      skip_ws_and_comments(it, end);

      if (it == end) {
         ctx.error = error_code::unexpected_end;
         return false;
      }

      if (*it == '"') {
         // Quoted key
         ++it;
         while (true) {
            const auto run_start = it;
            while (it != end && !toml::basic_string_dispatch_table[uint8_t(*it)]) {
               ++it;
            }
            if (it != run_start) {
               key.append(run_start, it);
            }
            if (it == end || *it == '"') {
               break;
            }
            if (toml::forbidden_control_table[uint8_t(*it)]) [[unlikely]] {
               ctx.error = error_code::invalid_control_character;
               return false;
            }
            ++it; // the scan only stops on a backslash once controls are ruled out
            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return false;
            }
            if (!append_toml_basic_escape(key, it, end)) {
               ctx.error = error_code::syntax_error;
               return false;
            }
            ++it;
         }

         if (it == end || *it != '"') {
            ctx.error = error_code::syntax_error;
            return false;
         }
         ++it; // Skip closing quote
      }
      else if (*it == '\'') {
         // Single-quoted (literal) key
         ++it;
         while (true) {
            const auto run_start = it;
            while (it != end && !toml::literal_string_dispatch_table[uint8_t(*it)]) {
               ++it;
            }
            if (it != run_start) {
               key.append(run_start, it);
            }
            if (it == end || *it == '\'') {
               break;
            }
            if (*it == '\n' || *it == '\r') {
               ctx.error = error_code::syntax_error;
               return false;
            }
            ctx.error = error_code::invalid_control_character;
            return false;
         }

         if (it == end || *it != '\'') {
            ctx.error = error_code::syntax_error;
            return false;
         }
         ++it; // Skip closing quote
      }
      else {
         // Bare key
         while (it != end && (std::isalnum(static_cast<unsigned char>(*it)) || *it == '_' || *it == '-')) {
            key.push_back(*it);
            ++it;
         }

         if (key.empty()) {
            ctx.error = error_code::syntax_error;
            return false;
         }
      }

      return true;
   }

   template <class Ctx, class It, class End>
   inline bool parse_toml_key(std::vector<std::string>& keys, Ctx& ctx, It& it, End end) noexcept
   {
      keys.clear();
      skip_ws_and_comments(it, end);

      if (it == end) {
         ctx.error = error_code::unexpected_end;
         return false;
      }

      while (true) {
         std::string key;

         if (it == end) {
            ctx.error = error_code::unexpected_end;
            return false;
         }

         if (*it == '"') {
            ++it;
            while (true) {
               const auto run_start = it;
               while (it != end && !toml::basic_string_dispatch_table[uint8_t(*it)]) {
                  ++it;
               }
               if (it != run_start) {
                  key.append(run_start, it);
               }
               if (it == end || *it == '"') {
                  break;
               }
               if (toml::forbidden_control_table[uint8_t(*it)]) [[unlikely]] {
                  ctx.error = error_code::invalid_control_character;
                  return false;
               }
               ++it; // the scan only stops on a backslash once controls are ruled out
               if (it == end) {
                  ctx.error = error_code::unexpected_end;
                  return false;
               }
               if (!append_toml_basic_escape(key, it, end)) {
                  ctx.error = error_code::syntax_error;
                  return false;
               }
               ++it;
            }

            if (it == end || *it != '"') {
               ctx.error = error_code::syntax_error;
               return false;
            }
            ++it; // skip closing quote
         }
         else if (*it == '\'') {
            ++it;
            while (true) {
               const auto run_start = it;
               while (it != end && !toml::literal_string_dispatch_table[uint8_t(*it)]) {
                  ++it;
               }
               if (it != run_start) {
                  key.append(run_start, it);
               }
               if (it == end || *it == '\'') {
                  break;
               }
               if (*it == '\n' || *it == '\r') {
                  ctx.error = error_code::syntax_error;
                  return false;
               }
               ctx.error = error_code::invalid_control_character;
               return false;
            }

            if (it == end || *it != '\'') {
               ctx.error = error_code::syntax_error;
               return false;
            }
            ++it; // skip closing quote
         }
         else {
            while (it != end && (std::isalnum(static_cast<unsigned char>(*it)) || *it == '_' || *it == '-')) {
               key.push_back(*it);
               ++it;
            }

            if (key.empty()) {
               ctx.error = error_code::syntax_error;
               return false;
            }
         }

         keys.push_back(std::move(key));

         skip_ws_and_comments(it, end);

         if (it == end || *it != '.') {
            break;
         }

         ++it; // skip '.', We know it's '.' because we've checked before
         skip_ws_and_comments(it, end);

         if (it == end) {
            ctx.error = error_code::unexpected_end;
            return false;
         }
      }

      return true;
   }

   // Consume the input that a key skipped by meta<T>::skip on parse names. After `key =` that is one
   // value. After a [table] or [[array]] header it is the table's body, every `key = value` line up to
   // the next header: skipping only the rest of the header line would leave those lines to be read
   // into the enclosing table.
   template <auto Opts, class Ctx, class It, class End>
   inline void skip_toml_member(Ctx& ctx, It& it, End end)
   {
      skip_ws_and_comments(it, end);
      if (it != end && *it != '\n' && *it != '\r') {
         skip_value<TOML>::template op<Opts>(ctx, it, end);
         return;
      }

      std::vector<std::string> key{};
      while (true) {
         skip_ws_newlines_and_comments(it, end);
         if (it == end || *it == '[') {
            return;
         }
         if (!parse_toml_key(key, ctx, it, end)) {
            return;
         }
         if (it == end || *it != '=') {
            ctx.error = error_code::syntax_error;
            return;
         }
         ++it; // skip '='
         skip_value<TOML>::template op<Opts>(ctx, it, end);
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }
      }
   }

   template <glaze_value_t T>
   struct from<TOML, T>
   {
      template <auto Opts, is_context Ctx, class It0, class It1>
      static void op(auto&& value, Ctx&& ctx, It0&& it, It1 end)
      {
         using V = std::decay_t<decltype(get_member(std::declval<T>(), meta_wrapper_v<T>))>;
         from<TOML, V>::template op<Opts>(get_member(value, meta_wrapper_v<T>), std::forward<Ctx>(ctx),
                                          std::forward<It0>(it), std::forward<It1>(end));
      }
   };

   // Silently consume any value bound to a glz::skip sentinel. Reached when a
   // type opts out of serialization via meta::value = glz::skip{}.
   template <>
   struct from<TOML, skip>
   {
      template <auto Opts>
      GLZ_ALWAYS_INLINE static void op(auto&&, is_context auto&& ctx, auto&&... args) noexcept
      {
         skip_value<TOML>::template op<Opts>(ctx, args...);
      }
   };

   namespace detail
   {
      constexpr bool is_toml_base_specifier(char c) noexcept { return (c == 'x' || c == 'b' || c == 'o'); }

      constexpr int toml_specified_base(char c) noexcept
      {
         switch (c) {
         case 'x':
            return 16;
         case 'b':
            return 2;
         case 'o':
            return 8;
         }

         // Should never reach here, but seems a good default.
         return 10;
      }

      constexpr bool is_any_toml_digit(char c) noexcept
      {
         if (c >= '0' && c <= '9') {
            return true;
         }

         if (c >= 'a' && c <= 'f') {
            return true;
         }

         if (c >= 'A' && c <= 'F') {
            return true;
         }

         return false;
      }

      constexpr bool is_valid_toml_digit(char c, int base) noexcept
      {
         if (base <= 10) {
            return c >= '0' && c < ('0' + base);
         }

         return is_any_toml_digit(c);
      }

      constexpr int char_to_digit(char c) noexcept
      {
         if (c >= '0' && c <= '9') return c - '0';
         if (c >= 'a' && c <= 'z') return c - 'a' + 10;
         if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
         return -1;
      }

      struct unsigned_accumulator
      {
        private:
         int base = 10;

        public:
         constexpr void inform_base(int b) noexcept { base = b; }

         constexpr bool is_valid_digit(char c) const noexcept { return is_valid_toml_digit(c, base); }

         template <std::unsigned_integral T>
         constexpr bool try_accumulate(T& v, int digit) const noexcept
         {
            if (digit < 0 || digit >= this->base) [[unlikely]] {
               return false;
            }

            // Check overflow.
            const auto max_without_overflow = ((std::numeric_limits<T>::max)() - digit) / this->base;
            if (v > max_without_overflow) [[unlikely]] {
               return false;
            }

            v = static_cast<T>(v * this->base + digit);

            return true;
         }
      };

      struct signed_accumulator
      {
        private:
         int base = 10;
         bool negated = false;

        public:
         constexpr void inform_negated() noexcept { this->negated = true; }

         constexpr void inform_base(int b) noexcept { base = b; }

         constexpr bool is_valid_digit(char c) const noexcept { return is_valid_toml_digit(c, base); }

         template <std::signed_integral T>
         constexpr bool try_accumulate(T& v, int digit) const noexcept
         {
            if (digit < 0 || digit >= this->base) [[unlikely]] {
               return false;
            }

            if (this->negated) {
               // Check underflow.
               const auto min_without_underflow = ((std::numeric_limits<T>::min)() + digit) / this->base;
               if (v < min_without_underflow) [[unlikely]] {
                  return false;
               }

               v = static_cast<T>(v * this->base - digit);

               return true;
            }

            // Check overflow.
            const auto max_without_overflow = ((std::numeric_limits<T>::max)() - digit) / this->base;
            if (v > max_without_overflow) [[unlikely]] {
               return false;
            }

            v = static_cast<T>(v * this->base + digit);

            return true;
         }
      };

      template <std::integral T>
      constexpr bool parse_toml_integer(T& v, auto&& it, auto end) noexcept
      {
         // Ensure the caller gave us at least one character.
         if (it == end) [[unlikely]] {
            return false;
         }

         auto accumulator = [] {
            if constexpr (std::unsigned_integral<T>) {
               return unsigned_accumulator{};
            }
            else {
               return signed_accumulator{};
            }
         }();

         bool saw_negative_sign = false;
         bool saw_sign = false; // Tracks whether +/- was supplied so prefixed bases can reject it.

         if (*it == '-') {
            saw_negative_sign = true;
            saw_sign = true;
            ++it;

            if (it == end) [[unlikely]] {
               return false;
            }

            if constexpr (std::signed_integral<T>) {
               accumulator.inform_negated();
            }
         }

         if (*it == '+') {
            // Only a single leading sign is permitted.
            if (saw_sign) [[unlikely]] {
               return false;
            }

            ++it;
            saw_sign = true;

            if (it == end) [[unlikely]] {
               return false;
            }
         }

         if (it == end) [[unlikely]] {
            return false;
         }

         if (*it == '_') [[unlikely]] {
            return false;
         }

         int base = 10;
         bool base_overridden = false;

         if (*it == '0') {
            auto next = it;
            ++next;

            if (next == end) {
               it = next;
               v = 0;
               return true;
            }

            if (*next == '_') [[unlikely]] {
               return false;
            }

            if (is_toml_base_specifier(*next)) {
               // Switching to hexadecimal/octal/binary after 0.
               base = toml_specified_base(*next);
               base_overridden = true;

               it = next;
               ++it;

               if (it == end) [[unlikely]] {
                  return false;
               }

               if (not is_valid_toml_digit(*it, base)) [[unlikely]] {
                  return false;
               }
            }
            else if (is_any_toml_digit(*next)) [[unlikely]] {
               // Decimal literals like 0123 are invalid.
               return false;
            }
            else {
               it = next;
               v = 0;
               return true;
            }
         }

         if (base_overridden) {
            accumulator.inform_base(base);

            // Only non-negative values are allowed for prefixed bases.
            if (saw_sign) [[unlikely]] {
               return false;
            }
         }

         v = 0;
         bool saw_digit = false;

         // Consume digits (with optional underscores) while respecting overflow limits.
         while (true) {
            if (it == end) {
               break;
            }

            if (*it == '_') {
               ++it;

               if (it == end) [[unlikely]] {
                  return false;
               }

               if (not is_any_toml_digit(*it)) [[unlikely]] {
                  return false;
               }
            }
            else if (not is_any_toml_digit(*it)) {
               break;
            }

            const auto digit = char_to_digit(*it);

            if (not accumulator.try_accumulate(v, digit)) {
               return false;
            }

            saw_digit = true;
            ++it;
         }

         if (not saw_digit) [[unlikely]] {
            return false;
         }

         if constexpr (std::unsigned_integral<T>) {
            if (saw_negative_sign && v != 0) [[unlikely]] {
               return false;
            }
         }

         return true;
      }

      constexpr bool is_toml_number_terminator(const char c) noexcept
      {
         return c == ',' || c == ']' || c == '}' || c == '\n' || c == '\r' || c == '#' || c == ' ' || c == '\t';
      }

      template <std::floating_point T>
      bool parse_toml_special_float(T& value, auto& it, auto end) noexcept
      {
         auto p = it;
         bool negative = false;

         if (p != end && (*p == '+' || *p == '-')) {
            negative = (*p == '-');
            ++p;
         }

         if ((end - p) >= 3 && p[0] == 'i' && p[1] == 'n' && p[2] == 'f') {
            const auto next = p + 3;
            if (next != end && !is_toml_number_terminator(*next)) {
               return false;
            }

            value = negative ? -std::numeric_limits<T>::infinity() : std::numeric_limits<T>::infinity();
            it = next;
            return true;
         }

         if ((end - p) >= 3 && p[0] == 'n' && p[1] == 'a' && p[2] == 'n') {
            const auto next = p + 3;
            if (next != end && !is_toml_number_terminator(*next)) {
               return false;
            }

            value = std::numeric_limits<T>::quiet_NaN();
            if (negative) {
               value = -value;
            }
            it = next;
            return true;
         }

         return false;
      }
   }

   template <num_t T>
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         using V = decay_keep_volatile_t<decltype(value)>;
         if constexpr (int_t<V>) {
            if (not detail::parse_toml_integer(value, it, end)) [[unlikely]] {
               ctx.error = error_code::parse_number_failure;
               return;
            }
         }
         else {
            if (detail::parse_toml_special_float(value, it, end)) {
               return;
            }

            auto [ptr, ec] = glz::from_chars<false>(it, end, value); // Always treat as non-null-terminated
            if (ec != std::errc()) [[unlikely]] {
               ctx.error = error_code::parse_number_failure;
               return;
            }
            it = ptr;
         }
      }
   };

   template <string_t T>
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         value.clear();
         skip_ws_and_comments(it, end);

         if (it == end) {
            ctx.error = error_code::unexpected_end;
            return;
         }

         if (it + 2 < end && *it == '"' && *(it + 1) == '"' && *(it + 2) == '"') {
            // Basic Multiline String
            it += 3; // Skip """
            if (it != end && *it == '\n') { // Skip initial newline
               ++it;
            }
            else if (it + 1 < end && *it == '\r' && *(it + 1) == '\n') { // Skip initial CRLF
               it += 2;
            }

            while (it + 2 < end && !(*it == '"' && *(it + 1) == '"' && *(it + 2) == '"')) {
               if (*it == '\\') {
                  ++it;
                  if (it == end) {
                     ctx.error = error_code::unexpected_end;
                     return;
                  }
                  // Escaped newline continuation in multiline basic strings
                  if (*it == '\n') {
                     // Trim all whitespace after escaped newline until non-whitespace or actual newline
                     while (it + 1 < end &&
                            (*(it + 1) == ' ' || *(it + 1) == '\t' || *(it + 1) == '\r' || *(it + 1) == '\n')) {
                        ++it;
                        if (*it == '\n') break; // Stop if we hit an actual newline
                     }
                  }
                  else if (*it == '\r') { // part of CRLF, handle similar to \n
                     if (it + 1 < end && *(it + 1) == '\n') ++it;
                     while (it + 1 < end &&
                            (*(it + 1) == ' ' || *(it + 1) == '\t' || *(it + 1) == '\r' || *(it + 1) == '\n')) {
                        ++it;
                        if (*it == '\n') break;
                     }
                  }
                  else if (!append_toml_basic_escape(value, it, end)) {
                     ctx.error = error_code::syntax_error;
                     return;
                  }
               }
               else {
                  const auto run_start = it;
                  while (it + 2 < end && !toml::multiline_basic_dispatch_table[uint8_t(*it)]) {
                     ++it;
                  }
                  if (it != run_start) {
                     value.append(run_start, it);
                  }
                  if (it + 2 >= end) {
                     break; // unterminated; reported by the check after the loop
                  }
                  if (toml::forbidden_control_multiline_table[uint8_t(*it)]) [[unlikely]] {
                     ctx.error = error_code::invalid_control_character;
                     return;
                  }
                  if (*it == '\\') {
                     continue; // hand the escape back to the branch above
                  }
                  if (*(it + 1) == '"' && *(it + 2) == '"') {
                     break; // closing delimiter
                  }
                  value.push_back('"'); // a lone quote inside the string
               }
               ++it;
            }

            if (it + 2 >= end || !(*it == '"' && *(it + 1) == '"' && *(it + 2) == '"')) {
               ctx.error = error_code::syntax_error; // Unterminated multiline string
               return;
            }
            it += 3; // Skip closing """
         }
         else if (*it == '"') {
            // Basic string
            ++it; // Skip opening quote

            while (true) {
               const auto run_start = it;
               while (it != end && !toml::basic_string_dispatch_table[uint8_t(*it)]) {
                  ++it;
               }
               if (it != run_start) {
                  value.append(run_start, it);
               }
               if (it == end || *it == '"') {
                  break;
               }
               if (*it == '\n' || *it == '\r') { // Newlines not allowed in single-line basic strings
                  ctx.error = error_code::syntax_error;
                  return;
               }
               if (toml::forbidden_control_table[uint8_t(*it)]) [[unlikely]] {
                  ctx.error = error_code::invalid_control_character;
                  return;
               }
               ++it; // the scan only stops on a backslash once controls are ruled out
               if (it == end) {
                  ctx.error = error_code::unexpected_end;
                  return;
               }
               if (!append_toml_basic_escape(value, it, end)) {
                  ctx.error = error_code::syntax_error;
                  return;
               }
               ++it;
            }

            if (it == end || *it != '"') {
               ctx.error = error_code::syntax_error;
               return;
            }
            ++it; // Skip closing quote
         }
         else if (it + 2 < end && *it == '\'' && *(it + 1) == '\'' && *(it + 2) == '\'') {
            // Literal Multiline String
            it += 3; // Skip '''
            if (it != end && *it == '\n') { // Skip initial newline
               ++it;
            }
            else if (it + 1 < end && *it == '\r' && *(it + 1) == '\n') { // Skip initial CRLF
               it += 2;
            }

            while (it + 2 < end && !(*it == '\'' && *(it + 1) == '\'' && *(it + 2) == '\'')) {
               const auto run_start = it;
               while (it + 2 < end && !toml::multiline_literal_dispatch_table[uint8_t(*it)]) {
                  ++it;
               }
               if (it != run_start) {
                  value.append(run_start, it);
               }
               if (it + 2 >= end) {
                  break;
               }
               if (toml::forbidden_control_multiline_table[uint8_t(*it)]) [[unlikely]] {
                  ctx.error = error_code::invalid_control_character;
                  return;
               }
               if (*(it + 1) == '\'' && *(it + 2) == '\'') {
                  break; // closing delimiter
               }
               value.push_back(*it); // a lone quote inside the string
               ++it;
            }

            if (it + 2 >= end || !(*it == '\'' && *(it + 1) == '\'' && *(it + 2) == '\'')) {
               ctx.error = error_code::syntax_error; // Unterminated multiline literal string
               return;
            }
            it += 3; // Skip closing '''
         }
         else if (*it == '\'') {
            // Literal string
            ++it; // Skip opening quote

            while (true) {
               const auto run_start = it;
               while (it != end && !toml::literal_string_dispatch_table[uint8_t(*it)]) {
                  ++it;
               }
               if (it != run_start) {
                  value.append(run_start, it);
               }
               if (it == end || *it == '\'') {
                  break;
               }
               if (*it == '\n' || *it == '\r') { // Newlines not allowed in single-line literal strings
                  ctx.error = error_code::syntax_error;
                  return;
               }
               ctx.error = error_code::invalid_control_character;
               return;
            }

            if (it == end || *it != '\'') {
               ctx.error = error_code::syntax_error;
               return;
            }
            ++it; // Skip closing quote
         }
         else {
            // Bare string (not typical in TOML values, but handle it if necessary for some edge cases)
            // TOML spec does not allow bare strings for values. This path should ideally not be hit for valid TOML.
            // If it is, it's likely an error or a deviation.
            // For now, let's assume this is an error according to strict TOML.
            ctx.error = error_code::syntax_error;
            return;
            /*
            while (it != end && *it != '\n' && *it != '\r' && *it != '#') {
               value.push_back(*it);
               ++it;
            }

            // Trim trailing whitespace
            while (!value.empty() && (value.back() == ' ' || value.back() == '\t')) {
               value.pop_back();
            }
            */
         }
      }
   };

   template <bool_t T>
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         if (it + 4 <= end &&
             std::string_view(it, 4) == "true") { // TODO: Maybe we can use the bool_true from header.hpp
            value = true;
            it += 4;
         }
         else if (it + 5 <= end &&
                  std::string_view(it, 5) == "false") { // TODO: Maybe we can use the bool_false from header.hpp
            value = false;
            it += 5;
         }
         else {
            ctx.error = error_code::expected_true_or_false;
            return;
         }
      }
   };

   // Enum with glz::meta/glz::enumerate - reads string representation
   template <class T>
      requires(is_named_enum<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto& value, is_context auto&& ctx, It&& it, auto end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         // TOML enum values are expected as quoted strings: "EnumValue"
         if (*it != '"') [[unlikely]] {
            ctx.error = error_code::expected_quote;
            return;
         }
         ++it;

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         // Find the closing quote to determine string length
         auto start = it;
         while (it != end && *it != '"') {
            ++it;
         }

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         const auto n = static_cast<size_t>(it - start);
         ++it; // skip closing quote

         constexpr auto N = reflect<T>::size;

         if constexpr (N == 1) {
            // Single enum value - just verify it matches
            static constexpr auto key = glz::get<0>(reflect<T>::keys);
            if (n == key.size() && std::string_view(start, n) == key) {
               value = glz::get<0>(reflect<T>::values);
            }
            else {
               ctx.error = error_code::unexpected_enum;
            }
         }
         else {
            static constexpr auto HashInfo = hash_info<T>;

            const auto index = decode_hash_with_size<TOML, T, HashInfo, HashInfo.type>::op(start, start + n, n);

            if (index >= N) [[unlikely]] {
               ctx.error = error_code::unexpected_enum;
               return;
            }

            // Use visit to convert runtime index to compile-time index
            visit<N>(
               [&]<size_t I>() {
                  // Verify the key matches (hash collision check)
                  static constexpr auto key = glz::get<I>(reflect<T>::keys);
                  if (n == key.size() && std::string_view(start, n) == key) [[likely]] {
                     value = glz::get<I>(reflect<T>::values);
                  }
                  else {
                     ctx.error = error_code::unexpected_enum;
                  }
               },
               index);
         }
      }
   };

   // Raw enum (without glz::meta) - reads as underlying numeric type
   template <class T>
      requires(std::is_enum_v<T> && !glaze_enum_t<T> && !meta_keys<T> && !custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto& value, is_context auto&& ctx, It&& it, auto end) noexcept
      {
         std::underlying_type_t<std::decay_t<T>> x{};
         from<TOML, decltype(x)>::template op<Opts>(x, ctx, it, end);
         value = static_cast<std::decay_t<T>>(x);
      }
   };

   // ============================================
   // std::chrono deserialization
   // ============================================

   // Duration: parsed generically (from the bare rep count) by the
   // from<uint32_t Format, is_duration T> specialization in core/chrono.hpp.

   // system_clock::time_point: parse from TOML native datetime (RFC 3339)
   // TOML datetimes are NOT quoted - they're native values
   // Format: YYYY-MM-DDTHH:MM:SS[.fraction][Z|+HH:MM|-HH:MM]
   // Also accepts space instead of T, and seconds can be omitted
   template <is_system_time_point T>
      requires(not custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It0, class It1>
      static void op(auto&& value, is_context auto&& ctx, It0&& it, It1 end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]]
            return;

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         // Find the start of datetime and determine its length
         const auto start = it;

         // Helper to parse N digits starting at given pointer
         auto parse_digits = [](const auto* s, size_t count) -> int {
            int val = 0;
            for (size_t i = 0; i < count; ++i) {
               const char c = s[i];
               if (c < '0' || c > '9') return -1;
               val = val * 10 + (c - '0');
            }
            return val;
         };

         // Consume datetime characters (digits, -, :, T, space, ., Z, +)
         while (it != end) {
            const char c = *it;
            if ((c >= '0' && c <= '9') || c == '-' || c == ':' || c == 'T' || c == 't' || c == ' ' || c == '.' ||
                c == 'Z' || c == 'z' || c == '+') {
               ++it;
            }
            else {
               break;
            }
         }

         const auto n = static_cast<size_t>(it - start);

         // Minimum: YYYY-MM-DDTHH:MM = 16 chars (seconds optional in TOML)
         if (n < 16) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         const char* s = &(*start);

         // YYYY-MM-DDTHH:MM (T can be space)
         const int yr = parse_digits(s, 4);
         const int mo = parse_digits(s + 5, 2);
         const int dy = parse_digits(s + 8, 2);
         const int hr = parse_digits(s + 11, 2);
         const int mi = parse_digits(s + 14, 2);

         // Validate basic structure
         if (yr < 0 || mo < 0 || dy < 0 || hr < 0 || mi < 0 || s[4] != '-' || s[7] != '-' ||
             (s[10] != 'T' && s[10] != 't' && s[10] != ' ') || s[13] != ':') [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         // Validate ranges
         if (mo < 1 || mo > 12 || dy < 1 || dy > 31 || hr > 23 || mi > 59) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         // Parse optional seconds
         size_t pos = 16;
         int sc = 0;
         if (pos < n && s[pos] == ':') {
            ++pos;
            if (pos + 2 > n) [[unlikely]] {
               ctx.error = error_code::parse_error;
               return;
            }
            sc = parse_digits(s + pos, 2);
            if (sc < 0 || sc > 59) [[unlikely]] {
               ctx.error = error_code::parse_error;
               return;
            }
            pos += 2;
         }

         // Parse optional fractional seconds
         int64_t subsec_nanos = 0;
         if (pos < n && s[pos] == '.') {
            ++pos;
            int64_t frac = 0;
            int digits = 0;
            while (pos < n && s[pos] >= '0' && s[pos] <= '9') {
               if (digits < 9) {
                  frac = frac * 10 + (s[pos] - '0');
                  ++digits;
               }
               ++pos;
            }
            // Scale to nanoseconds
            static constexpr int64_t scale[] = {1000000000, 100000000, 10000000, 1000000, 100000,
                                                10000,      1000,      100,      10,      1};
            if (digits > 0 && digits <= 9) {
               subsec_nanos = frac * scale[digits];
            }
         }

         // Parse timezone: Z or +HH:MM or -HH:MM (defaults to UTC if missing - local datetime)
         int tz_offset_seconds = 0;
         if (pos < n) {
            if (s[pos] == 'Z' || s[pos] == 'z') {
               // UTC - no adjustment needed
            }
            else if (s[pos] == '+' || s[pos] == '-') {
               const int utc_adjustment = (s[pos] == '+') ? -1 : 1;
               ++pos;
               if (pos + 2 > n) [[unlikely]] {
                  ctx.error = error_code::parse_error;
                  return;
               }
               const int tz_hour = parse_digits(s + pos, 2);
               if (tz_hour < 0 || tz_hour > 23) [[unlikely]] {
                  ctx.error = error_code::parse_error;
                  return;
               }
               pos += 2;
               int tz_min = 0;
               if (pos < n && s[pos] == ':') ++pos;
               if (pos + 2 <= n) {
                  const int m = parse_digits(s + pos, 2);
                  if (m >= 0 && m <= 59) {
                     tz_min = m;
                  }
               }
               tz_offset_seconds = utc_adjustment * (tz_hour * 3600 + tz_min * 60);
            }
         }

         // Construct time_point using std::chrono calendar types
         using namespace std::chrono;

         const auto ymd = year_month_day{year{yr}, month{static_cast<unsigned>(mo)}, day{static_cast<unsigned>(dy)}};
         if (!ymd.ok()) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         // Summed in seconds and cast by make_sys_time: a nanosecond intermediate wraps int64
         // for years outside 1677-2262 even when the target can hold them.
         const auto tp =
            sys_seconds{sys_days{ymd}} + hours{hr} + minutes{mi} + seconds{sc} + seconds{tz_offset_seconds};
         if (!chrono_detail::make_sys_time(value, tp.time_since_epoch(), nanoseconds{subsec_nanos})) [[unlikely]] {
            ctx.error = error_code::parse_error;
         }
      }
   };

   // year_month_day: parse from TOML Local Date (YYYY-MM-DD)
   template <is_year_month_day T>
      requires(not custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It0, class It1>
      static void op(auto&& value, is_context auto&& ctx, It0&& it, It1 end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]]
            return;

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         // Helper to parse N digits
         auto parse_digits = [](const auto* s, size_t count) -> int {
            int val = 0;
            for (size_t i = 0; i < count; ++i) {
               const char c = s[i];
               if (c < '0' || c > '9') return -1;
               val = val * 10 + (c - '0');
            }
            return val;
         };

         const auto start = it;

         // Consume date characters (digits and -)
         while (it != end) {
            const char c = *it;
            if ((c >= '0' && c <= '9') || c == '-') {
               ++it;
            }
            else {
               break;
            }
         }

         const auto n = static_cast<size_t>(it - start);

         // Minimum: YYYY-MM-DD = 10 chars
         if (n < 10) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         const char* s = &(*start);

         const int yr = parse_digits(s, 4);
         const int mo = parse_digits(s + 5, 2);
         const int dy = parse_digits(s + 8, 2);

         if (yr < 0 || mo < 0 || dy < 0 || s[4] != '-' || s[7] != '-') [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         if (mo < 1 || mo > 12 || dy < 1 || dy > 31) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         using namespace std::chrono;
         value = year_month_day{year{yr}, month{static_cast<unsigned>(mo)}, day{static_cast<unsigned>(dy)}};

         if (!value.ok()) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }
      }
   };

   // hh_mm_ss: parse from TOML Local Time (HH:MM:SS[.fraction])
   template <is_hh_mm_ss T>
      requires(not custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It0, class It1>
      static void op(auto&& value, is_context auto&& ctx, It0&& it, It1 end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]]
            return;

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         // Helper to parse N digits
         auto parse_digits = [](const auto* s, size_t count) -> int {
            int val = 0;
            for (size_t i = 0; i < count; ++i) {
               const char c = s[i];
               if (c < '0' || c > '9') return -1;
               val = val * 10 + (c - '0');
            }
            return val;
         };

         const auto start = it;

         // Consume time characters (digits, :, .)
         while (it != end) {
            const char c = *it;
            if ((c >= '0' && c <= '9') || c == ':' || c == '.') {
               ++it;
            }
            else {
               break;
            }
         }

         const auto n = static_cast<size_t>(it - start);

         // Minimum: HH:MM = 5 chars (seconds optional per TOML spec)
         if (n < 5) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         const char* s = &(*start);

         const int hr = parse_digits(s, 2);
         const int mi = parse_digits(s + 3, 2);

         if (hr < 0 || mi < 0 || s[2] != ':') [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         if (hr > 23 || mi > 59) [[unlikely]] {
            ctx.error = error_code::parse_error;
            return;
         }

         // Parse optional seconds
         size_t pos = 5;
         int sc = 0;
         if (pos < n && s[pos] == ':') {
            ++pos;
            if (pos + 2 > n) [[unlikely]] {
               ctx.error = error_code::parse_error;
               return;
            }
            sc = parse_digits(s + pos, 2);
            if (sc < 0 || sc > 59) [[unlikely]] {
               ctx.error = error_code::parse_error;
               return;
            }
            pos += 2;
         }

         // Parse optional fractional seconds
         int64_t subsec_nanos = 0;
         if (pos < n && s[pos] == '.') {
            ++pos;
            int64_t frac = 0;
            int digits = 0;
            while (pos < n && s[pos] >= '0' && s[pos] <= '9') {
               if (digits < 9) {
                  frac = frac * 10 + (s[pos] - '0');
                  ++digits;
               }
               ++pos;
            }
            static constexpr int64_t scale[] = {1000000000, 100000000, 10000000, 1000000, 100000,
                                                10000,      1000,      100,      10,      1};
            if (digits > 0 && digits <= 9) {
               subsec_nanos = frac * scale[digits];
            }
         }

         using namespace std::chrono;
         using Precision = typename std::remove_cvref_t<T>::precision;

         auto total_duration =
            hours{hr} + minutes{mi} + seconds{sc} + duration_cast<Precision>(nanoseconds{subsec_nanos});
         value = std::remove_cvref_t<T>{total_duration};
      }
   };

   // steady_clock / high_resolution_clock time_points: parsed generically (from the bare
   // count) by the from<uint32_t Format, is_count_time_point T> specialization in core/chrono.hpp.

   // for set types (emplaceable but not emplace_backable)
   template <class T>
      requires(readable_array_t<T> && !emplace_backable<T> && !resizable<T> && emplaceable<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end || *it != '[') {
            ctx.error = error_code::syntax_error;
            return;
         }

         ++it; // Skip '['
         skip_ws_newlines_and_comments(it, end);

         value.clear();

         // Handle empty array
         if (it != end && *it == ']') {
            ++it;
            return;
         }

         while (it != end) {
            using V = range_value_t<T>;
            V v;
            from<TOML, V>::template op<Opts>(v, ctx, it, end);
            if (bool(ctx.error)) [[unlikely]]
               return;
            value.emplace(std::move(v));

            skip_ws_newlines_and_comments(it, end);

            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return;
            }

            if (*it == ']') {
               ++it;
               return;
            }
            else if (*it == ',') {
               ++it;
               skip_ws_newlines_and_comments(it, end);
               if (it != end && *it == ']') {
                  ++it;
                  return;
               }
            }
            else {
               ctx.error = error_code::syntax_error;
               return;
            }
         }

         ctx.error = error_code::unexpected_end;
      }
   };

   // for types like std::vector, std::array, std::deque, etc.
   template <class T>
      requires(readable_array_t<T> && (emplace_backable<T> || !resizable<T>) && !emplaceable<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end || *it != '[') {
            ctx.error = error_code::syntax_error;
            return;
         }

         ++it; // Skip '['
         skip_ws_newlines_and_comments(it, end);

         // Handle empty array
         if (it != end && *it == ']') {
            ++it;
            return;
         }

         size_t index = 0;
         while (it != end) {
            using value_type = typename std::remove_cvref_t<T>::value_type;

            if constexpr (emplace_backable<T>) {
               auto& element = value.emplace_back();
               from<TOML, value_type>::template op<Opts>(element, ctx, it, end);
            }
            else {
               // For fixed-size arrays like std::array
               if (index >= value.size()) {
                  ctx.error = error_code::exceeded_static_array_size;
                  return;
               }
               from<TOML, value_type>::template op<Opts>(value[index], ctx, it, end);
               ++index;
            }

            if (bool(ctx.error)) {
               return;
            }

            skip_ws_newlines_and_comments(it, end);

            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return;
            }

            if (*it == ']') {
               ++it;
               return;
            }
            else if (*it == ',') {
               ++it;
               skip_ws_newlines_and_comments(it, end);
               if (it != end && *it == ']') {
                  ++it;
                  return;
               }
            }
            else {
               ctx.error = error_code::syntax_error;
               return;
            }
         }

         ctx.error = error_code::unexpected_end;
      }
   };

   namespace detail
   {
      // Report the first required key of U that the document never assigned.
      template <auto Opts, class U, class Ctx>
      void check_required_fields(const bit_array<reflect<U>::size>& fields, Ctx& ctx)
      {
         if constexpr (check_error_on_missing_keys(Opts)) {
            if (bool(ctx.error)) {
               return;
            }
            static constexpr auto required = required_fields<U, Opts>();
            for (size_t i = 0; i < reflect<U>::size; ++i) {
               if (required[i] && not fields[i]) {
                  ctx.custom_error_message = reflect<U>::keys[i];
                  ctx.error = error_code::missing_key;
                  return;
               }
            }
         }
      }

      // TOML lets one struct be assembled from disjoint regions of a document: [server] may be
      // followed by an unrelated table and then [server.tls], and a dotted key can reach into a
      // table that a later section fills in further. Which members were assigned therefore cannot
      // be settled where a table body ends, the way it can for a JSON or YAML object -- the rest of
      // the document may still be carrying them.
      //
      // missing_key_record accumulates that across the whole read. Nodes mirror the shape of the
      // values the document actually touched: one per struct, and for an array of tables one for
      // the array holding one per element. error_on_missing_keys is then resolved by walking the
      // tree once the document has been parsed.
      struct missing_key_record
      {
         std::vector<bool> assigned{}; // one flag per reflected member of the struct this node mirrors
         // Keyed by member index, or by element index on the node standing in for an array of
         // tables. A vector rather than a map: a document names a handful of keys per struct.
         std::vector<std::pair<size_t, std::unique_ptr<missing_key_record>>> children{};
         // An inline table is self-contained by the TOML grammar, so it is checked where it is
         // parsed and this node's flags are never filled in. Set to keep the final walk off it.
         bool checked_in_place = false;

         explicit missing_key_record(const size_t member_count) : assigned(member_count, false) {}

         void assign(const size_t index)
         {
            if (index < assigned.size()) {
               assigned[index] = true;
            }
         }

         missing_key_record* child(const size_t key, const size_t member_count)
         {
            for (auto& [k, node] : children) {
               if (k == key) {
                  return node.get();
               }
            }
            children.emplace_back(key, std::make_unique<missing_key_record>(member_count));
            return children.back().second.get();
         }
      };

      // Whether a value is a TOML table -- a reflected struct, seen through any nullable wrapper.
      // The missing-key tracker follows required keys into one, and a "[array.sub]" header descends
      // into one. A custom reader owns its own parsing, so it is left alone by both.
      template <class T>
      consteval bool toml_table_like()
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (custom_read<U> || glaze_value_t<U>) {
            return false;
         }
         else if constexpr (glaze_object_t<U> || reflectable<U>) {
            return true;
         }
         else if constexpr (nullable_like<U>) {
            return toml_table_like<std::remove_cvref_t<decltype(*std::declval<U&>())>>();
         }
         else {
            return false;
         }
      }

      template <class T>
      consteval size_t tracked_member_count()
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (custom_read<U> || glaze_value_t<U>) {
            return 0;
         }
         else if constexpr (glaze_object_t<U> || reflectable<U>) {
            return reflect<U>::size;
         }
         else if constexpr (nullable_like<U>) {
            return tracked_member_count<std::remove_cvref_t<decltype(*std::declval<U&>())>>();
         }
         else {
            return 0;
         }
      }

      // Whether a "[array.sub]" header can descend into this value's last element: a growable array
      // whose elements are tables, seen through any nullable wrapper. resolve_array_of_tables
      // unwraps the member before it classifies it, so this has to as well or "[[a]]" and "[a.sub]"
      // disagree about whether the same optional<vector<T>> is tracked.
      template <class T>
      consteval bool is_toml_array_of_tables()
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (glaze_object_t<U> || reflectable<U> || custom_read<U>) {
            return false; // a struct that happens to have emplace_back is still a struct
         }
         else if constexpr (nullable_like<U>) {
            return is_toml_array_of_tables<std::remove_cvref_t<decltype(*std::declval<U&>())>>();
         }
         else if constexpr (emplace_backable<U> && requires { typename U::value_type; }) {
            return toml_table_like<typename U::value_type>();
         }
         else {
            return false;
         }
      }

      // Element type of an array of tables, unwrapped the same way, so its node can be sized. The
      // nullable case has to come first: std::optional<std::vector<T>> has a value_type of its own,
      // and reading that one would size every element node at zero.
      template <class T>
      consteval size_t tracked_element_count()
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (nullable_like<U>) {
            return tracked_element_count<std::remove_cvref_t<decltype(*std::declval<U&>())>>();
         }
         else if constexpr (requires { typename U::value_type; }) {
            return tracked_member_count<typename U::value_type>();
         }
         else {
            return 0;
         }
      }

      template <auto Opts, class T, class It, class End>
      void read_tracked(T& value, auto& ctx, It& it, End end, missing_key_record* node);

      template <auto Opts, class T, class Ctx>
      void check_missing_keys(T&& value, const missing_key_record& node, Ctx& ctx);

      template <auto Opts, class T, class Ctx>
      void check_missing_keys_at(T&& value, const missing_key_record& node, Ctx& ctx);

      template <auto Opts, class T, class It, class End, class Ctx>
      inline void parse_inline_table_members(T&& value, It&& it, End end, Ctx&& ctx)
      {
         using U = std::remove_cvref_t<T>;
         static constexpr auto N = reflect<U>::size;
         static constexpr auto HashInfo = hash_info<U>;
         // An inline table is the complete value of the struct it fills -- the grammar forbids
         // adding to it from anywhere else in the document -- so its required keys are settled here
         // rather than deferred to the whole-document walk.
         [[maybe_unused]] bit_array<N> fields{};
         // TODO: Think if it's feasible to write a function to find out the deepest nested structure
         // and use it instead of vector

         while (it != end) {
            skip_ws_and_comments(it, end);

            if (it == end) {
               break; // Truncated; settled below the loop
            }

            if (*it == '\n' || *it == '\r') {
               skip_to_next_line(ctx, it, end);
               continue;
            }

            if (*it == '}') {
               ++it; // Consume '}'
               check_required_fields<Opts, U>(fields, ctx);
               return; // End of inline table
            }

            std::string key_str;
            // std::vector<std::string> key_str; // TODO: std::string is used temporarily, we may swap it to view later
            // on or as said before completely switch to array

            if (!parse_toml_key(key_str, ctx, it, end)) {
               return;
            }

            skip_ws_and_comments(it, end);

            if (it == end || *it != '=') {
               ctx.error = error_code::syntax_error;
               return;
            }

            ++it; // Skip '='
            skip_ws_and_comments(it, end);

            if (it == end) {
               ctx.error = error_code::unexpected_end; // Value expected
               return;
            }

            const auto index = decode_hash_with_size<TOML, U, HashInfo, HashInfo.type>::op(
               key_str.data(), key_str.data() + key_str.size(), key_str.size());

            const bool key_matches = index < N && key_str == reflect<U>::keys[index];

            if (key_matches) [[likely]] {
               if constexpr (check_error_on_missing_keys(Opts)) {
                  fields[index] = true;
               }
               visit<N>(
                  [&]<size_t I>() {
                     // A field skipped on parse consumes its value in a branch of its own, so its
                     // reader is never instantiated -- see `skipped_by_meta`.
                     if constexpr (skipped_by_meta<U, I, operation::parse>) {
                        if (I == index) {
                           skip_value<TOML>::template op<Opts>(ctx, it, end);
                        }
                     }
                     else if (I == index) {
                        decltype(auto) member_obj = [&]() -> decltype(auto) {
                           if constexpr (reflectable<U>) {
                              // For reflectable types, to_tie provides access to members
                              return get<I>(to_tie(value));
                           }
                           else {
                              // For glaze_object_t, reflect<T>::values gives member metadata
                              // and get_member accesses the actual member value
                              return get_member(value, get<I>(reflect<U>::values));
                           }
                        }();

                        // member_obj is now a reference to the actual member or its wrapper
                        using member_type = std::decay_t<decltype(member_obj)>;
                        from<TOML, member_type>::template op<Opts>(member_obj, ctx, it, end);
                     }
                     return !bool(ctx.error);
                  },
                  index);

               if (bool(ctx.error)) [[unlikely]] {
                  return;
               }
            }
            else {
               if constexpr (Opts.error_on_unknown_keys) {
                  ctx.error = error_code::unknown_key;
                  return;
               }
               else { // else used to fix MSVC unreachable code warning
                  skip_value<TOML>::template op<Opts>(ctx, it, end);
                  if (bool(ctx.error)) [[unlikely]] {
                     return;
                  }
               }
            }

            skip_ws_and_comments(it, end);
            if (it == end) {
               break; // Truncated; settled below the loop
            }

            if (*it == '}') {
               // Handled at the start of the loop
               continue;
            }
            else if (*it == ',') {
               ++it; // Consume comma
               skip_ws_and_comments(it, end);
               if (it != end && *it == '}') { // Trailing comma case like { key = "val", }
                  // This is allowed by TOML v1.0.0 for inline tables
                  // The '}' will be consumed at the start of the next iteration.
               }
            }
            else {
               ctx.error = error_code::syntax_error; // Expected comma or '}'
               return;
            }
         }

         // A well-formed inline table returns at its '}' above, so falling out of the loop means
         // the document ended inside it.
         if (not bool(ctx.error)) {
            ctx.error = error_code::unexpected_end;
         }
      }
   }

   template <auto Opts, class T>
   inline bool resolve_nested(T& root, std::span<std::string> path, auto& ctx, auto& it, auto& end,
                              detail::missing_key_record* node)
   {
      if constexpr (not nullable_like<T> && detail::is_toml_array_of_tables<T>()) {
         // "[array.sub]" names a sub-table of the last element "[[array]]" defined, per TOML
         // v1.0.0. Without descending here the header resolves to nothing and the body under it is
         // read as though it belonged to the enclosing table.
         if (root.empty()) {
            // Nothing has opened an element for this to belong to. No TOML document reaches here:
            // "[a.sub]" requires a preceding "[[a]]", and a dotted "a.sub = 1" cannot address an
            // array at all. Inventing an element would accept both.
            ctx.error = error_code::syntax_error;
            return false;
         }
         [[maybe_unused]] detail::missing_key_record* element_node = nullptr;
         if constexpr (check_error_on_missing_keys(Opts)) {
            if (node) {
               element_node = node->child(root.size() - 1, detail::tracked_element_count<T>());
            }
         }
         return resolve_nested<Opts>(root.back(), path, ctx, it, end, element_node);
      }
      else if constexpr (!(glz::reflectable<T> || glz::glaze_object_t<T>)) {
         return true;
      }
      else {
         using U = std::remove_cvref_t<T>;
         static constexpr auto N = reflect<U>::size;
         static constexpr auto HashInfo = hash_info<U>;
         const auto index = decode_hash_with_size<TOML, U, HashInfo, HashInfo.type>::op(
            path.front().data(), path.front().data() + path.front().size(), path.front().size());

         const bool key_matches = index < N && path.front() == reflect<U>::keys[index];

         if (key_matches) [[likely]] {
            if constexpr (check_error_on_missing_keys(Opts)) {
               // Naming a key assigns it, whether the document stops here or reaches through it
               // into a deeper table.
               if (node) {
                  node->assign(index);
               }
            }
            visit<N>(
               [&]<size_t I>() {
                  // A field skipped on parse is consumed, value or table body, in a branch of its own
                  // so its reader is never instantiated -- see `skipped_by_meta`.
                  if constexpr (skipped_by_meta<U, I, operation::parse>) {
                     if (I == index) {
                        skip_toml_member<Opts>(ctx, it, end);
                     }
                  }
                  else if (I == index) {
                     decltype(auto) member_obj = [&]() -> decltype(auto) {
                        if constexpr (reflectable<U>) {
                           return get<I>(to_tie(root));
                        }
                        else {
                           return get_member(root, get<I>(reflect<U>::values));
                        }
                     }();

                     using member_type = std::decay_t<decltype(member_obj)>;
                     [[maybe_unused]] detail::missing_key_record* member_node = nullptr;
                     if constexpr (check_error_on_missing_keys(Opts)) {
                        if (node) {
                           if constexpr (detail::toml_table_like<member_type>()) {
                              member_node = node->child(I, detail::tracked_member_count<member_type>());
                           }
                           else if constexpr (detail::is_toml_array_of_tables<member_type>()) {
                              // The array's node holds one child per element; the descent below
                              // picks the element out of it.
                              member_node = node->child(I, 0);
                           }
                        }
                     }

                     if (!(path.size() - 1)) {
                        if constexpr (check_error_on_missing_keys(Opts) && detail::toml_table_like<member_type>()) {
                           detail::read_tracked<toml::is_internal_on<Opts>()>(member_obj, ctx, it, end, member_node);
                        }
                        else {
                           from<TOML, member_type>::template op<toml::is_internal_on<Opts>()>(member_obj, ctx, it, end);
                        }
                     }
                     else {
                        return resolve_nested<Opts>(member_obj, path.subspan(1), ctx, it, end, member_node);
                     }
                  }
                  return !bool(ctx.error);
               },
               index);
         }
         else {
            if constexpr (Opts.error_on_unknown_keys) {
               ctx.error = error_code::unknown_key;
               return false;
            }
            else { // else used to fix MSVC unreachable code warning
               skip_value<TOML>::template op<Opts>(ctx, it, end);
               return !bool(ctx.error);
            }
         }
         return !bool(ctx.error);
      }
   }

   template <auto Opts, nullable_like T>
   inline bool resolve_nested(T& root, std::span<std::string> path, auto& ctx, auto& it, auto& end,
                              detail::missing_key_record* node)
   {
      if (!root) {
         if (!nullable_emplace<Opts>(root, ctx)) {
            return false;
         }
      }
      return resolve_nested<Opts>(*root, path, ctx, it, end, node);
   }

   // Helper to resolve an array-of-tables path and emplace a new element
   // Returns true if successful, false if error
   template <auto Opts, class T>
   inline bool resolve_array_of_tables(T& root, std::span<std::string> path, auto& ctx, auto& it, auto& end,
                                       detail::missing_key_record* node)
   {
      if constexpr (!(glz::reflectable<T> || glz::glaze_object_t<T>)) {
         ctx.error = error_code::syntax_error;
         return false;
      }
      else {
         using U = std::remove_cvref_t<T>;
         static constexpr auto N = reflect<U>::size;
         static constexpr auto HashInfo = hash_info<U>;
         const auto index = decode_hash_with_size<TOML, U, HashInfo, HashInfo.type>::op(
            path.front().data(), path.front().data() + path.front().size(), path.front().size());

         const bool key_matches = index < N && path.front() == reflect<U>::keys[index];

         if (key_matches) [[likely]] {
            if constexpr (check_error_on_missing_keys(Opts)) {
               if (node) {
                  node->assign(index);
               }
            }
            bool success = false;
            visit<N>(
               [&]<size_t I>() {
                  // See resolve_nested: a field skipped on parse is consumed without being read.
                  if constexpr (skipped_by_meta<U, I, operation::parse>) {
                     if (I == index) {
                        skip_toml_member<Opts>(ctx, it, end);
                        success = !bool(ctx.error);
                     }
                  }
                  else if (I == index) {
                     decltype(auto) raw_member_obj = [&]() -> decltype(auto) {
                        if constexpr (reflectable<U>) {
                           return get<I>(to_tie(root));
                        }
                        else {
                           return get_member(root, get<I>(reflect<U>::values));
                        }
                     }();
                     using raw_member_type = std::decay_t<decltype(raw_member_obj)>;

                     decltype(auto) member_obj = [&]() -> decltype(auto) {
                        if constexpr (nullable_like<raw_member_type>) {
                           if (!raw_member_obj) {
                              if (!nullable_emplace<Opts>(raw_member_obj, ctx)) {
                                 success = false;
                              }
                           }
                           return *raw_member_obj;
                        }
                        else {
                           return raw_member_obj;
                        }
                     }();
                     using member_type = std::decay_t<decltype(member_obj)>;

                     // The array itself gets a node whose children are its elements, so that a
                     // later [array.of.tables.sub] header lands on the element it extends.
                     [[maybe_unused]] detail::missing_key_record* member_node = nullptr;
                     if constexpr (check_error_on_missing_keys(Opts)) {
                        if (node) {
                           if constexpr (emplace_backable<member_type>) {
                              member_node = node->child(I, 0);
                           }
                           else if constexpr (detail::toml_table_like<member_type>()) {
                              member_node = node->child(I, detail::tracked_member_count<member_type>());
                           }
                        }
                     }

                     if (path.size() == 1) {
                        // This is the final element in the path - it should be an array
                        if constexpr (emplace_backable<member_type>) {
                           // Emplace a new element and parse into it
                           auto& new_element = member_obj.emplace_back();
                           using element_type = std::decay_t<decltype(new_element)>;
                           if constexpr (check_error_on_missing_keys(Opts) && detail::toml_table_like<element_type>()) {
                              detail::missing_key_record* element_node =
                                 member_node ? member_node->child(member_obj.size() - 1,
                                                                  detail::tracked_member_count<element_type>())
                                             : nullptr;
                              detail::read_tracked<toml::is_internal_on<Opts>()>(new_element, ctx, it, end,
                                                                                 element_node);
                           }
                           else {
                              from<TOML, element_type>::template op<toml::is_internal_on<Opts>()>(new_element, ctx, it,
                                                                                                  end);
                           }
                           success = !bool(ctx.error);
                        }
                        else {
                           // Not an array type that supports emplace_back
                           ctx.error = error_code::syntax_error;
                           success = false;
                        }
                     }
                     else {
                        // More path segments remaining - recurse
                        if constexpr (emplace_backable<member_type>) {
                           // If this is an array, navigate to the last element
                           if (member_obj.empty()) {
                              // Need to add an element first
                              member_obj.emplace_back();
                           }
                           [[maybe_unused]] detail::missing_key_record* element_node = nullptr;
                           if constexpr (check_error_on_missing_keys(Opts)) {
                              if (member_node) {
                                 element_node = member_node->child(member_obj.size() - 1,
                                                                   detail::tracked_element_count<member_type>());
                              }
                           }
                           success = resolve_array_of_tables<Opts>(member_obj.back(), path.subspan(1), ctx, it, end,
                                                                   element_node);
                        }
                        else if constexpr (glz::reflectable<member_type> || glz::glaze_object_t<member_type> ||
                                           nullable_like<member_type>) {
                           success =
                              resolve_array_of_tables<Opts>(member_obj, path.subspan(1), ctx, it, end, member_node);
                        }
                        else {
                           ctx.error = error_code::syntax_error;
                           success = false;
                        }
                     }
                  }
               },
               index);
            return success;
         }
         else {
            if constexpr (Opts.error_on_unknown_keys) {
               ctx.error = error_code::unknown_key;
               return false;
            }
            else { // else used to fix MSVC unreachable code warning
               // Skip unknown key's content
               skip_value<TOML>::template op<Opts>(ctx, it, end);
               return !bool(ctx.error);
            }
         }
      }
   }

   template <auto Opts, nullable_like T>
   inline bool resolve_array_of_tables(T& root, std::span<std::string> path, auto& ctx, auto& it, auto& end,
                                       detail::missing_key_record* node)
   {
      if (!root) {
         if (!nullable_emplace<Opts>(root, ctx)) {
            return false;
         }
      }
      return resolve_array_of_tables<Opts>(*root, path, ctx, it, end, node);
   }

   // ============================================
   // Map support for TOML
   // ============================================

   namespace detail
   {
      // Concept to detect types with a variant 'data' member (like generic_json)
      template <class T>
      concept has_variant_data_member =
         requires { requires is_variant<std::remove_cvref_t<decltype(std::declval<T>().data)>>; };

      // Find the index of the first map alternative in a variant
      template <class Variant, size_t I = 0>
      constexpr size_t find_map_alternative_index()
      {
         if constexpr (I >= std::variant_size_v<Variant>) {
            return std::variant_npos;
         }
         else {
            using Alt = std::variant_alternative_t<I, Variant>;
            if constexpr (writable_map_t<Alt>) {
               return I;
            }
            else {
               return find_map_alternative_index<Variant, I + 1>();
            }
         }
      }

      // Helper to resolve a dotted key path into a nested map, creating entries as needed
      // Returns a reference to the innermost value where data should be stored
      // Note: Not inline because this function is recursive
      template <auto Opts, class T>
      bool resolve_nested_map(T& root, std::span<std::string> path, auto& ctx, auto& it, auto& end)
      {
         // A dotted key recurses one frame per path segment, with nothing else bounding the
         // descent, so an adversarial key like "a.a.a.…=1" otherwise overflows the stack. Share
         // the same depth budget the variant reader uses so combined nesting is bounded too.
         depth_guard guard{ctx};
         if (!guard) [[unlikely]] {
            return false;
         }

         if (path.empty()) {
            ctx.error = error_code::syntax_error;
            return false;
         }

         using Value = typename T::mapped_type;
         const auto map_it = root.find(path.front());
         const bool exists = (map_it != root.end());

         if (path.size() == 1) {
            // Duplicate assignment for an already-defined key is invalid.
            if (exists) {
               ctx.error = error_code::syntax_error;
               return false;
            }

            // Last key in path - parse the value directly.
            from<TOML, Value>::template op<toml::is_internal_on<Opts>()>(root[path.front()], ctx, it, end);
            return !bool(ctx.error);
         }

         // Navigate/create nested map
         if constexpr (is_variant<Value>) {
            constexpr auto map_idx = find_map_alternative_index<Value>();
            if constexpr (map_idx != std::variant_npos) {
               using MapType = std::variant_alternative_t<map_idx, Value>;

               if (!exists) {
                  auto& nested_value = root[path.front()];
                  nested_value.template emplace<map_idx>();
                  return resolve_nested_map<Opts>(std::get<MapType>(nested_value), path.subspan(1), ctx, it, end);
               }

               auto& nested_value = map_it->second;
               if (!std::holds_alternative<MapType>(nested_value)) {
                  ctx.error = error_code::syntax_error;
                  return false;
               }

               return resolve_nested_map<Opts>(std::get<MapType>(nested_value), path.subspan(1), ctx, it, end);
            }
            else {
               ctx.error = error_code::no_matching_variant_type;
               return false;
            }
         }
         else if constexpr (has_variant_data_member<Value>) {
            using DataType = decltype(std::declval<Value&>().data);
            constexpr auto map_idx = find_map_alternative_index<std::remove_reference_t<DataType>>();
            if constexpr (map_idx != std::variant_npos) {
               using MapType = std::variant_alternative_t<map_idx, std::remove_reference_t<DataType>>;

               if (!exists) {
                  auto& nested_value = root[path.front()];
                  nested_value.data.template emplace<map_idx>();
                  return resolve_nested_map<Opts>(std::get<MapType>(nested_value.data), path.subspan(1), ctx, it, end);
               }

               auto& nested_value = map_it->second;
               if (!std::holds_alternative<MapType>(nested_value.data)) {
                  ctx.error = error_code::syntax_error;
                  return false;
               }

               return resolve_nested_map<Opts>(std::get<MapType>(nested_value.data), path.subspan(1), ctx, it, end);
            }
            else {
               ctx.error = error_code::no_matching_variant_type;
               return false;
            }
         }
         else if constexpr (readable_map_t<Value>) {
            if (!exists) {
               return resolve_nested_map<Opts>(root[path.front()], path.subspan(1), ctx, it, end);
            }

            return resolve_nested_map<Opts>(map_it->second, path.subspan(1), ctx, it, end);
         }
         else {
            // Value type doesn't support nesting.
            ctx.error = error_code::syntax_error;
            return false;
         }
      }

      // Helper to ensure a path of nested maps exists (for table section headers)
      // This creates the nested map structure without parsing a value
      // Note: Not inline because this function is recursive
      template <auto Opts, class T>
      bool ensure_map_path(T& root, std::span<std::string> path, auto& ctx)
      {
         // A table header "[a.a.a.…]" recurses one frame per path segment with nothing bounding
         // the descent, so cap it on the shared depth budget to avoid a stack overflow.
         depth_guard guard{ctx};
         if (!guard) [[unlikely]] {
            return false;
         }

         if (path.empty()) {
            return true;
         }

         using Value = typename T::mapped_type;
         const auto map_it = root.find(path.front());
         const bool exists = (map_it != root.end());

         if (path.size() == 1) {
            // Last key in path - just ensure the map exists at this location
            if constexpr (is_variant<Value>) {
               constexpr auto map_idx = find_map_alternative_index<Value>();
               if constexpr (map_idx != std::variant_npos) {
                  using MapType = std::variant_alternative_t<map_idx, Value>;

                  if (!exists) {
                     auto& nested_value = root[path.front()];
                     nested_value.template emplace<map_idx>();
                     return true;
                  }

                  if (!std::holds_alternative<MapType>(map_it->second)) {
                     ctx.error = error_code::syntax_error;
                     return false;
                  }

                  // Re-defining an already-defined table is invalid.
                  ctx.error = error_code::syntax_error;
                  return false;
               }
               else {
                  ctx.error = error_code::no_matching_variant_type;
                  return false;
               }
            }
            else if constexpr (has_variant_data_member<Value>) {
               using DataType = std::remove_reference_t<decltype(std::declval<Value&>().data)>;
               constexpr auto map_idx = find_map_alternative_index<DataType>();
               if constexpr (map_idx != std::variant_npos) {
                  using MapType = std::variant_alternative_t<map_idx, DataType>;

                  if (!exists) {
                     auto& nested_value = root[path.front()];
                     nested_value.data.template emplace<map_idx>();
                     return true;
                  }

                  if (!std::holds_alternative<MapType>(map_it->second.data)) {
                     ctx.error = error_code::syntax_error;
                     return false;
                  }

                  // Re-defining an already-defined table is invalid.
                  ctx.error = error_code::syntax_error;
                  return false;
               }
               else {
                  ctx.error = error_code::no_matching_variant_type;
                  return false;
               }
            }
            else if constexpr (readable_map_t<Value>) {
               if (exists) {
                  ctx.error = error_code::syntax_error;
                  return false;
               }

               root[path.front()];
               return true;
            }
            else {
               ctx.error = error_code::syntax_error;
               return false;
            }
         }
         else {
            // Navigate deeper
            if constexpr (is_variant<Value>) {
               constexpr auto map_idx = find_map_alternative_index<Value>();
               if constexpr (map_idx != std::variant_npos) {
                  using MapType = std::variant_alternative_t<map_idx, Value>;

                  if (!exists) {
                     auto& nested_value = root[path.front()];
                     nested_value.template emplace<map_idx>();
                     return ensure_map_path<Opts>(std::get<MapType>(nested_value), path.subspan(1), ctx);
                  }

                  auto& nested_value = map_it->second;
                  if (!std::holds_alternative<MapType>(nested_value)) {
                     ctx.error = error_code::syntax_error;
                     return false;
                  }

                  return ensure_map_path<Opts>(std::get<MapType>(nested_value), path.subspan(1), ctx);
               }
               else {
                  ctx.error = error_code::no_matching_variant_type;
                  return false;
               }
            }
            else if constexpr (has_variant_data_member<Value>) {
               using DataType = std::remove_reference_t<decltype(std::declval<Value&>().data)>;
               constexpr auto map_idx = find_map_alternative_index<DataType>();
               if constexpr (map_idx != std::variant_npos) {
                  using MapType = std::variant_alternative_t<map_idx, DataType>;

                  if (!exists) {
                     auto& nested_value = root[path.front()];
                     nested_value.data.template emplace<map_idx>();
                     return ensure_map_path<Opts>(std::get<MapType>(nested_value.data), path.subspan(1), ctx);
                  }

                  auto& nested_value = map_it->second;
                  if (!std::holds_alternative<MapType>(nested_value.data)) {
                     ctx.error = error_code::syntax_error;
                     return false;
                  }

                  return ensure_map_path<Opts>(std::get<MapType>(nested_value.data), path.subspan(1), ctx);
               }
               else {
                  ctx.error = error_code::no_matching_variant_type;
                  return false;
               }
            }
            else if constexpr (readable_map_t<Value>) {
               if (!exists) {
                  return ensure_map_path<Opts>(root[path.front()], path.subspan(1), ctx);
               }

               return ensure_map_path<Opts>(map_it->second, path.subspan(1), ctx);
            }
            else {
               ctx.error = error_code::syntax_error;
               return false;
            }
         }
      }

      // Parse inline table {...} into a map
      template <auto Opts, class T>
      inline void parse_toml_inline_table_map(T& value, auto& it, auto& end, auto& ctx)
      {
         // Already consumed the opening '{'
         skip_ws_and_comments(it, end);

         if (it != end && *it == '}') {
            ++it; // Empty inline table
            return;
         }

         while (it != end) {
            skip_ws_and_comments(it, end);
            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return;
            }

            if (*it == '\n' || *it == '\r') {
               skip_to_next_line(ctx, it, end);
               continue;
            }

            if (*it == '}') {
               ++it;
               return;
            }

            std::vector<std::string> path;
            if (!parse_toml_key(path, ctx, it, end)) {
               return;
            }

            if (it == end || *it != '=') {
               ctx.error = error_code::syntax_error;
               return;
            }
            ++it; // Skip '='
            skip_ws_and_comments(it, end);

            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return;
            }

            if (!resolve_nested_map<Opts>(value, std::span{path}, ctx, it, end)) {
               return;
            }

            skip_ws_and_comments(it, end);
            if (it == end) {
               ctx.error = error_code::unexpected_end;
               return;
            }

            if (*it == '}') {
               ++it;
               return;
            }
            else if (*it == ',') {
               ++it;
               skip_ws_and_comments(it, end);
            }
            else {
               ctx.error = error_code::syntax_error;
               return;
            }
         }
      }
   } // namespace detail

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4702) // unreachable code from if constexpr
#endif
   template <class T>
      requires(readable_map_t<T> && not glaze_object_t<T> && not reflectable<T> && not custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         skip_ws_and_comments(it, end);

         if (it == end) {
            return; // Empty input is valid (empty map)
         }

         // Check if starting with inline table
         if (*it == '{') {
            ++it;
            detail::parse_toml_inline_table_map<Opts>(value, it, end, ctx);
            return;
         }

         // TOML document-level parsing
         // Track current section path instead of a pointer to avoid UB from casting
         // between map types with different comparators (e.g., std::less<> vs std::less<std::string>)
         std::vector<std::string> current_section_path;

         while (it != end) {
            skip_ws_and_comments(it, end);
            if (it == end) {
               return;
            }
            if (*it == '\n' || *it == '\r') {
               skip_to_next_line(ctx, it, end);
               continue;
            }

            if (*it == '[') {
               if constexpr (toml::check_is_internal(Opts)) {
                  return; // if it's internal we return to root
               }

               ++it;
               if (it != end && *it == '[') {
                  // Array of tables [[name]] - not fully supported for maps yet
                  // For now, skip array of tables in map context
                  ctx.error = error_code::syntax_error;
                  return;
               }
               else {
                  // Table section [name]
                  skip_ws_and_comments(it, end);
                  current_section_path.clear();
                  if (!parse_toml_key(current_section_path, ctx, it, end)) {
                     return;
                  }
                  if (it == end || *it != ']') {
                     ctx.error = error_code::syntax_error;
                     return;
                  }
                  ++it; // skip ']'

                  // Ensure the nested map structure exists for this section
                  if (!detail::ensure_map_path<Opts>(value, std::span{current_section_path}, ctx)) {
                     return;
                  }
               }
            }
            else {
               // Key-value pair
               std::vector<std::string> key_path;
               if (!parse_toml_key(key_path, ctx, it, end)) {
                  return;
               }

               if (it == end || *it != '=') {
                  ctx.error = error_code::syntax_error;
                  return;
               }
               ++it; // Skip '='
               skip_ws_and_comments(it, end);

               if (it == end) {
                  ctx.error = error_code::unexpected_end;
                  return;
               }

               // Combine section path with key path for full navigation from root
               std::vector<std::string> full_path;
               full_path.reserve(current_section_path.size() + key_path.size());
               full_path.insert(full_path.end(), current_section_path.begin(), current_section_path.end());
               full_path.insert(full_path.end(), key_path.begin(), key_path.end());

               if (!detail::resolve_nested_map<Opts>(value, std::span{full_path}, ctx, it, end)) {
                  return;
               }
            }
         }
      }
#ifdef _MSC_VER
#pragma warning(pop)
#endif
   };

   template <class T>
      requires((glaze_object_t<T> || reflectable<T>) && not custom_read<T>)
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         if constexpr (check_error_on_missing_keys(Opts)) {
            // An inline table settles its own required keys where it is parsed, so a record built
            // for one is never read -- and an array of inline tables would allocate one per element.
            auto peek = it;
            skip_ws_newlines_and_comments(peek, end);
            if (peek != end && *peek == '{') {
               op_tracked<Opts>(value, ctx, it, end, nullptr);
               return;
            }
            // Entered without a record of what the enclosing document has already assigned, so this
            // parse owns the whole tree and resolves it once the value is complete.
            detail::missing_key_record record{reflect<std::remove_cvref_t<decltype(value)>>::size};
            op_tracked<Opts>(value, ctx, it, end, &record);
            if (not bool(ctx.error)) {
               detail::check_missing_keys<Opts>(value, record, ctx);
            }
         }
         else {
            op_tracked<Opts>(value, ctx, it, end, nullptr);
         }
      }

      // node carries which members the enclosing document has already assigned to this same value,
      // and collects the ones this call assigns. Null when error_on_missing_keys is off.
      template <auto Opts, class It>
      static void op_tracked(auto&& value, is_context auto&& ctx, It&& it, auto end,
                             [[maybe_unused]] detail::missing_key_record* node)
      {
         using U = std::remove_cvref_t<decltype(value)>;
         while (it != end) {
            // TODO: Introduce OPTS here
            skip_ws_and_comments(it, end);
            if (it == end) { // Empty input for an object is valid (empty object)
               return;
            }
            if (*it == '\n' || *it == '\r') {
               skip_to_next_line(ctx, it, end);
               continue;
            }

            // TODO: We probably should reorder that so that we dont check against less used inline table more often
            if (*it == '{') { // Check if it's an inline table
               // parse_inline_table_members settles required keys itself, so keep the document walk
               // off this node rather than reporting every member of it as missing.
               if constexpr (check_error_on_missing_keys(Opts)) {
                  if (node) {
                     node->checked_in_place = true;
                  }
               }
               ++it; // Consume '{'
               skip_ws_and_comments(it, end);
               if (it != end && *it == '}') { // Empty inline table {}
                  ++it;
                  detail::check_required_fields<Opts, U>({}, ctx);
                  return;
               }
               // TODO: Rewrite logic here, for now it works just fine so we leave it.
               detail::parse_inline_table_members<Opts>(value, it, end, ctx);
               // parse_inline_table_members consumes the final '}'. The inline table is the
               // entire value for this struct, so return rather than looping; otherwise an
               // enclosing inline table's ',' or '}' would be misparsed as the start of a key.
               return;
            }
            else if (*it == '[') { // Normal table or array of tables
               std::vector<std::string> path;

               if constexpr (toml::check_is_internal(Opts)) {
                  return; // if it's internal we return to root.
               }
               else {
                  ++it;
                  if (it != end && *it == '[') { // Array of tables [[name]]
                     ++it; // skip the second bracket
                     skip_ws_and_comments(it, end);

                     if (!parse_toml_key(path, ctx, it, end)) {
                        return;
                     }

                     // Expect closing ]]
                     skip_ws_and_comments(it, end);
                     if (it == end || *it != ']') {
                        ctx.error = error_code::syntax_error;
                        return;
                     }
                     ++it; // skip first ']'
                     if (it == end || *it != ']') {
                        ctx.error = error_code::syntax_error;
                        return;
                     }
                     ++it; // skip second ']'

                     // Navigate to the array and emplace a new element
                     if (!resolve_array_of_tables<Opts>(value, std::span{path}, ctx, it, end, node)) {
                        return;
                     }
                  }
                  else {
                     // Normal table [name]
                     skip_ws_and_comments(it, end);

                     if (!parse_toml_key(path, ctx, it, end)) {
                        return;
                     }
                     if (it == end || *it != ']') {
                        ctx.error = error_code::syntax_error;
                        return;
                     }
                     ++it; // skip ']'
                     if (!resolve_nested<Opts>(value, std::span{path}, ctx, it, end, node)) {
                        return;
                     }
                  }
               }
            }
            else {
               std::vector<std::string> path;
               skip_ws_and_comments(it, end);

               if (!parse_toml_key(path, ctx, it, end)) {
                  return;
               }

               if (it == end || *it != '=') {
                  ctx.error = error_code::syntax_error;
                  return;
               }

               ++it; // Skip '='
               skip_ws_and_comments(it, end);

               if (it == end) {
                  ctx.error = error_code::unexpected_end; // Value expected
                  return;
               }
               if (!resolve_nested<Opts>(value, std::span{path}, ctx, it, end, node)) {
                  return;
               }
            }
         }
      }
   };

   namespace detail
   {
      template <auto Opts, class T, class It, class End>
      void read_tracked(T& value, auto& ctx, It& it, End end, missing_key_record* node)
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (nullable_like<U>) {
            // Mirrors from<TOML, nullable_like>::op, but hands the node to the value inside rather
            // than losing it at the wrapper.
            skip_ws_and_comments(it, end);
            if (it == end) {
               value = {};
               return;
            }
            if (!value) {
               if (!nullable_emplace<Opts>(value, ctx)) {
                  return;
               }
            }
            read_tracked<Opts>(*value, ctx, it, end, node);
         }
         else {
            from<TOML, U>::template op_tracked<Opts>(value, ctx, it, end, node);
         }
      }

      template <auto Opts, class T, class Ctx>
      void check_missing_keys(T&& value, const missing_key_record& node, Ctx& ctx)
      {
         using U = std::remove_cvref_t<T>;
         static constexpr auto N = reflect<U>::size;

         if (node.checked_in_place) {
            return;
         }

         static constexpr auto required = required_fields<U, Opts>();
         for (size_t i = 0; i < N; ++i) {
            if (required[i] && not(i < node.assigned.size() && node.assigned[i])) {
               ctx.custom_error_message = reflect<U>::keys[i];
               ctx.error = error_code::missing_key;
               return;
            }
         }

         if constexpr (N > 0) {
            for (const auto& [index, child] : node.children) {
               visit<N>(
                  [&]<size_t I>() {
                     if (I == index) {
                        decltype(auto) member_obj = [&]() -> decltype(auto) {
                           if constexpr (reflectable<U>) {
                              return get<I>(to_tie(value));
                           }
                           else {
                              return get_member(value, get<I>(reflect<U>::values));
                           }
                        }();
                        check_missing_keys_at<Opts>(member_obj, *child, ctx);
                     }
                     return not bool(ctx.error);
                  },
                  index);
               if (bool(ctx.error)) {
                  return;
               }
            }
         }
      }

      template <auto Opts, class T, class Ctx>
      void check_missing_keys_at(T&& value, const missing_key_record& node, Ctx& ctx)
      {
         using U = std::remove_cvref_t<T>;
         if constexpr (nullable_like<U>) {
            if (value) {
               check_missing_keys_at<Opts>(*value, node, ctx);
            }
         }
         else if constexpr (glaze_object_t<U> || reflectable<U>) {
            check_missing_keys<Opts>(value, node, ctx);
         }
         else if constexpr (emplace_backable<U>) {
            // An array of tables: this node's children are keyed by element index.
            for (const auto& [element, child] : node.children) {
               if (element >= value.size()) {
                  continue;
               }
               auto iter = std::begin(value);
               std::advance(iter, static_cast<std::ptrdiff_t>(element));
               check_missing_keys_at<Opts>(*iter, *child, ctx);
               if (bool(ctx.error)) {
                  return;
               }
            }
         }
      }
   }

   // ============================================
   // Variant support for TOML
   // ============================================

   namespace detail
   {
      // Type traits for TOML variant type classification
      template <class T>
      concept toml_variant_bool_type = glz::bool_t<T>;

      template <class T>
      concept toml_variant_string_type = glz::str_t<T>;

      template <class T>
      concept toml_variant_int_type = glz::int_t<T> && !glz::bool_t<T>;

      template <class T>
      concept toml_variant_signed_int_type = std::signed_integral<T> && !glz::bool_t<T>;

      template <class T>
      concept toml_variant_unsigned_int_type = std::unsigned_integral<T> && !glz::bool_t<T>;

      template <class T>
      concept toml_variant_float_type = std::floating_point<T>;

      template <class T>
      concept toml_variant_array_type = glz::readable_array_t<T> && !glz::str_t<T>;

      template <class T>
      concept toml_variant_object_type = (glz::glaze_object_t<T> || glz::reflectable<T> || glz::writable_map_t<T>);

      template <class T>
      concept toml_variant_null_type = glz::null_t<T>;

      // Type trait wrappers for template use
      template <class T>
      struct is_toml_variant_bool : std::bool_constant<toml_variant_bool_type<T>>
      {};
      template <class T>
      struct is_toml_variant_string : std::bool_constant<toml_variant_string_type<T>>
      {};
      template <class T>
      struct is_toml_variant_int : std::bool_constant<toml_variant_int_type<T>>
      {};
      template <class T>
      struct is_toml_variant_signed_int : std::bool_constant<toml_variant_signed_int_type<T>>
      {};
      template <class T>
      struct is_toml_variant_unsigned_int : std::bool_constant<toml_variant_unsigned_int_type<T>>
      {};
      template <class T>
      struct is_toml_variant_float : std::bool_constant<toml_variant_float_type<T>>
      {};
      template <class T>
      struct is_toml_variant_array : std::bool_constant<toml_variant_array_type<T>>
      {};
      template <class T>
      struct is_toml_variant_object : std::bool_constant<toml_variant_object_type<T>>
      {};
      template <class T>
      struct is_toml_variant_null : std::bool_constant<toml_variant_null_type<T>>
      {};

      // Count types in variant matching a trait
      template <class Variant, template <class> class Trait>
      struct toml_variant_count_impl;

      template <template <class> class Trait, class... Ts>
      struct toml_variant_count_impl<std::variant<Ts...>, Trait>
      {
         static constexpr size_t value = (size_t(Trait<Ts>::value) + ... + 0);
      };

      template <class Variant, template <class> class Trait>
      constexpr size_t toml_variant_count_v = toml_variant_count_impl<Variant, Trait>::value;

      // Get first index matching trait (or variant_npos if none)
      template <class Variant, template <class> class Trait>
      struct toml_variant_first_index_impl;

      template <template <class> class Trait, class... Ts>
      struct toml_variant_first_index_impl<std::variant<Ts...>, Trait>
      {
         static constexpr size_t find()
         {
            size_t result = std::variant_npos;
            size_t idx = 0;
            ((Trait<Ts>::value && result == std::variant_npos ? (result = idx, ++idx) : ++idx), ...);
            return result;
         }
         static constexpr size_t value = find();
      };

      template <class Variant, template <class> class Trait>
      constexpr size_t toml_variant_first_index_v = toml_variant_first_index_impl<Variant, Trait>::value;

      // A '{' says the value is an inline table, but not which object alternative it is. Parse the
      // structurally deduced one, and on failure rewind and try each of the others, taking the
      // first that reads cleanly.
      //
      // Structural deduction is a guess, so a failure means "probably the wrong alternative" -- but
      // only for failures that say the shape does not fit. A missing_key failure is the caller's own
      // error_on_missing_keys strictness being enforced; retrying past it would answer a strict read
      // with a different alternative instead of the error the caller asked for. A depth overrun is a
      // property of the input rather than of the alternative, so retrying re-parses the whole
      // subtree for nothing, once per alternative at every level of the nest.
      template <auto Opts, class Variant, class It, class End>
      void read_object_alternative(Variant& value, auto& ctx, It& it, End end)
      {
         static constexpr auto n_alts = std::variant_size_v<Variant>;
         static constexpr auto deduced = toml_variant_first_index_v<Variant, is_toml_variant_object>;
         const auto start = it;

         const auto attempt = [&]<size_t I>() {
            it = start;
            ctx.error = error_code::none;
            ctx.custom_error_message = {};
            if (value.index() != I) {
               value.template emplace<I>();
            }
            using V = std::variant_alternative_t<I, Variant>;
            from<TOML, V>::template op<Opts>(std::get<I>(value), ctx, it, end);
         };

         attempt.template operator()<deduced>();
         // missing_key is the caller's own strictness rather than a sign the alternative is wrong --
         // but only while a wrong alternative would announce itself as unknown_key. With unknown
         // keys skipped the two are indistinguishable, so the others still have to be tried; when
         // none of them fits, the restore below hands back the strictness error either way.
         constexpr bool missing_key_is_final = Opts.error_on_unknown_keys;
         if (not bool(ctx.error) || ctx.error == error_code::exceeded_max_recursive_depth ||
             (missing_key_is_final && ctx.error == error_code::missing_key)) {
            return;
         }

         const auto deduced_error = ctx.error;
         const auto deduced_message = ctx.custom_error_message;
         const auto deduced_it = it;

         bool recovered = false;
         // Seeded from the latched budget rather than false: once it is spent, a level that still
         // ran one retry before finding out would parse its subtree twice, which is 2^depth over an
         // ambiguous nest. A spent budget has to stop the retry before it starts.
         bool exhausted = speculation_exhausted(ctx);
         for_each<n_alts>([&]<size_t I>() {
            if (recovered || exhausted || I == deduced) {
               return;
            }
            if constexpr (toml_variant_object_type<std::variant_alternative_t<I, Variant>>) {
               attempt.template operator()<I>();
               recovered = not bool(ctx.error);
               if (not recovered && not charge_speculation(ctx, size_t(it - start))) {
                  // Out of budget: an ambiguous nest re-parses the same subtree per alternative at
                  // every level, which is exponential. Stop retrying and keep what we have.
                  exhausted = true;
               }
            }
         });

         if (not recovered) {
            // Report what the structurally deduced alternative said rather than whichever retry
            // happened to run last.
            it = deduced_it;
            ctx.error = deduced_error;
            ctx.custom_error_message = deduced_message;
         }
      }

      // Detect if a TOML number is a float by scanning ahead
      // Returns true if the number contains float indicators (., e, E, inf, nan)
      // Returns false for hex (0x), octal (0o), and binary (0b) prefixed numbers
      template <class It, class End>
      inline bool is_toml_float(It it, End end) noexcept
      {
         // Skip leading sign
         if (it != end && (*it == '+' || *it == '-')) {
            ++it;
         }

         // Check for special float values
         if (it != end) {
            // Check for inf/nan (with optional sign already consumed)
            if (*it == 'i' || *it == 'n') {
               return true; // inf or nan
            }
            // Check for hex (0x), octal (0o), binary (0b) prefixes - these are always integers
            if (*it == '0') {
               auto next = it;
               ++next;
               if (next != end) {
                  const char prefix = *next;
                  if (prefix == 'x' || prefix == 'X' || prefix == 'o' || prefix == 'O' || prefix == 'b' ||
                      prefix == 'B') {
                     return false; // Always an integer
                  }
               }
            }
         }

         // Scan the number looking for float indicators
         while (it != end) {
            const char c = *it;
            if (c == '.' || c == 'e' || c == 'E') {
               return true;
            }
            // Stop at value terminators
            if (c == ',' || c == ']' || c == '}' || c == '\n' || c == '\r' || c == '#' || c == ' ' || c == '\t') {
               break;
            }
            ++it;
         }
         return false;
      }

      // Check if we're looking at 'true' or 'false' exactly (not an identifier starting with 't' or 'f')
      template <class It, class End>
      inline bool is_toml_bool(It it, End end) noexcept
      {
         if (it == end) return false;

         const char c = *it;
         if (c == 't') {
            // Check for "true"
            ++it;
            if (it == end || *it != 'r') return false;
            ++it;
            if (it == end || *it != 'u') return false;
            ++it;
            if (it == end || *it != 'e') return false;
            ++it;
            // Must be followed by a terminator
            if (it == end) return true;
            const char next = *it;
            return next == ',' || next == ']' || next == '}' || next == '\n' || next == '\r' || next == '#' ||
                   next == ' ' || next == '\t';
         }
         else if (c == 'f') {
            // Check for "false"
            ++it;
            if (it == end || *it != 'a') return false;
            ++it;
            if (it == end || *it != 'l') return false;
            ++it;
            if (it == end || *it != 's') return false;
            ++it;
            if (it == end || *it != 'e') return false;
            ++it;
            // Must be followed by a terminator
            if (it == end) return true;
            const char next = *it;
            return next == ',' || next == ']' || next == '}' || next == '\n' || next == '\r' || next == '#' ||
                   next == ' ' || next == '\t';
         }
         return false;
      }

      // Check if we're looking at 'inf' or 'nan' specifically (not an identifier starting with 'i' or 'n')
      template <class It, class End>
      inline bool is_inf_or_nan(It it, End end) noexcept
      {
         // Skip optional sign
         if (it != end && (*it == '+' || *it == '-')) {
            ++it;
         }
         if (it == end) return false;

         const char c = *it;
         if (c == 'i') {
            // Check for "inf"
            ++it;
            if (it != end && *it == 'n') {
               ++it;
               if (it != end && *it == 'f') {
                  ++it;
                  // Must be followed by a terminator
                  if (it == end) return true;
                  const char next = *it;
                  return next == ',' || next == ']' || next == '}' || next == '\n' || next == '\r' || next == '#' ||
                         next == ' ' || next == '\t';
               }
            }
            return false;
         }
         else if (c == 'n') {
            // Check for "nan"
            ++it;
            if (it != end && *it == 'a') {
               ++it;
               if (it != end && *it == 'n') {
                  ++it;
                  // Must be followed by a terminator
                  if (it == end) return true;
                  const char next = *it;
                  return next == ',' || next == ']' || next == '}' || next == '\n' || next == '\r' || next == '#' ||
                         next == ' ' || next == '\t';
               }
            }
            return false;
         }
         return false;
      }
   } // namespace detail

   template <class T>
      requires is_variant<std::remove_cvref_t<T>>
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end)
      {
         using Variant = std::remove_cvref_t<T>;

         if (bool(ctx.error)) [[unlikely]] {
            return;
         }

         // Nested arrays and inline tables recurse back through this reader, so cap the depth
         // here; a deeply nested value (e.g. "a=[[[[...") otherwise overflows the stack.
         depth_guard guard{ctx};
         if (!guard) [[unlikely]] {
            return;
         }

         skip_ws_and_comments(it, end);

         if (it == end) [[unlikely]] {
            ctx.error = error_code::unexpected_end;
            return;
         }

         const char c = *it;

         // Detect type based on first character
         if (c == '"' || c == '\'') {
            // String
            constexpr auto str_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_string>;
            if constexpr (str_count == 0) {
               ctx.error = error_code::no_matching_variant_type;
               return;
            }
            else {
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_string>;
               using V = std::variant_alternative_t<idx, Variant>;
               if (!std::holds_alternative<V>(value)) {
                  value.template emplace<idx>();
               }
               from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
            }
         }
         else if (c == '[') {
            // Array
            constexpr auto arr_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_array>;
            if constexpr (arr_count == 0) {
               ctx.error = error_code::no_matching_variant_type;
               return;
            }
            else {
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_array>;
               using V = std::variant_alternative_t<idx, Variant>;
               if (!std::holds_alternative<V>(value)) {
                  value.template emplace<idx>();
               }
               from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
            }
         }
         else if (c == '{') {
            // Inline table (object)
            constexpr auto obj_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_object>;
            if constexpr (obj_count == 0) {
               ctx.error = error_code::no_matching_variant_type;
               return;
            }
            else if constexpr (obj_count == 1) {
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_object>;
               using V = std::variant_alternative_t<idx, Variant>;
               if (!std::holds_alternative<V>(value)) {
                  value.template emplace<idx>();
               }
               from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
            }
            else {
               detail::read_object_alternative<Opts>(value, ctx, it, end);
            }
         }
         else if ((c == 't' || c == 'f') && detail::is_toml_bool(it, end)) {
            // Boolean (must be exactly 'true' or 'false', not identifiers starting with 't' or 'f')
            constexpr auto bool_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_bool>;
            if constexpr (bool_count == 0) {
               ctx.error = error_code::no_matching_variant_type;
               return;
            }
            else {
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_bool>;
               using V = std::variant_alternative_t<idx, Variant>;
               if (!std::holds_alternative<V>(value)) {
                  value.template emplace<idx>();
               }
               from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
            }
         }
         else if ((c >= '0' && c <= '9') || c == '+' || c == '-' ||
                  ((c == 'i' || c == 'n') && detail::is_inf_or_nan(it, end))) {
            // Number (including inf/nan) - need to determine if integer or float
            constexpr auto int_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_int>;
            constexpr auto float_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_float>;
            constexpr auto signed_int_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_signed_int>;
            constexpr auto unsigned_int_count =
               detail::toml_variant_count_v<Variant, detail::is_toml_variant_unsigned_int>;

            if constexpr (int_count == 0 && float_count == 0) {
               ctx.error = error_code::no_matching_variant_type;
               return;
            }
            else if constexpr (int_count == 0) {
               // Only float types available
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_float>;
               using V = std::variant_alternative_t<idx, Variant>;
               if (!std::holds_alternative<V>(value)) {
                  value.template emplace<idx>();
               }
               from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
            }
            else if constexpr (float_count == 0) {
               // Only integer types available - choose signed vs unsigned based on sign
               const bool is_negative = (c == '-');
               if constexpr (signed_int_count > 0 && unsigned_int_count > 0) {
                  // Both signed and unsigned available - pick based on sign
                  if (is_negative) {
                     constexpr auto idx =
                        detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_signed_int>;
                     using V = std::variant_alternative_t<idx, Variant>;
                     if (!std::holds_alternative<V>(value)) {
                        value.template emplace<idx>();
                     }
                     from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                  }
                  else {
                     constexpr auto idx =
                        detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_unsigned_int>;
                     using V = std::variant_alternative_t<idx, Variant>;
                     if (!std::holds_alternative<V>(value)) {
                        value.template emplace<idx>();
                     }
                     from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                  }
               }
               else {
                  // Only one integer signedness available
                  constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_int>;
                  using V = std::variant_alternative_t<idx, Variant>;
                  if (!std::holds_alternative<V>(value)) {
                     value.template emplace<idx>();
                  }
                  from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
               }
            }
            else {
               // Both int and float types available - need to detect which
               if (detail::is_toml_float(it, end)) {
                  constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_float>;
                  using V = std::variant_alternative_t<idx, Variant>;
                  if (!std::holds_alternative<V>(value)) {
                     value.template emplace<idx>();
                  }
                  from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
               }
               else {
                  // Integer - choose signed vs unsigned based on sign
                  const bool is_negative = (c == '-');
                  if constexpr (signed_int_count > 0 && unsigned_int_count > 0) {
                     // Both signed and unsigned available - pick based on sign
                     if (is_negative) {
                        constexpr auto idx =
                           detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_signed_int>;
                        using V = std::variant_alternative_t<idx, Variant>;
                        if (!std::holds_alternative<V>(value)) {
                           value.template emplace<idx>();
                        }
                        from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                     }
                     else {
                        constexpr auto idx =
                           detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_unsigned_int>;
                        using V = std::variant_alternative_t<idx, Variant>;
                        if (!std::holds_alternative<V>(value)) {
                           value.template emplace<idx>();
                        }
                        from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                     }
                  }
                  else {
                     // Only one integer signedness available
                     constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_int>;
                     using V = std::variant_alternative_t<idx, Variant>;
                     if (!std::holds_alternative<V>(value)) {
                        value.template emplace<idx>();
                     }
                     from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                  }
               }
            }
         }
         else {
            // Identifiers (a-z, A-Z, _) at document root indicate key-value pairs
            // Check if the variant has a map alternative we can use
            const bool is_identifier = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
            constexpr auto map_idx = detail::find_map_alternative_index<Variant>();

            if constexpr (map_idx != std::variant_npos) {
               if (is_identifier) {
                  // Parse as a TOML document with key-value pairs into the map alternative
                  using V = std::variant_alternative_t<map_idx, Variant>;
                  if (!std::holds_alternative<V>(value)) {
                     value.template emplace<map_idx>();
                  }
                  from<TOML, V>::template op<Opts>(std::get<V>(value), ctx, it, end);
                  return;
               }
            }

            // Unknown type - could be null or invalid
            constexpr auto null_count = detail::toml_variant_count_v<Variant, detail::is_toml_variant_null>;
            if constexpr (null_count > 0) {
               // Try to parse as null (for std::nullptr_t or similar)
               constexpr auto idx = detail::toml_variant_first_index_v<Variant, detail::is_toml_variant_null>;
               value.template emplace<idx>();
               // Note: TOML doesn't have a native null, so this may fail unless
               // custom handling is provided
            }
            else {
               ctx.error = error_code::syntax_error;
            }
         }
      }
   };

   // Nullable types: std::optional, std::unique_ptr, std::shared_ptr, raw pointers
   template <nullable_like T>
   struct from<TOML, T>
   {
      template <auto Opts, class It>
      static void op(auto&& value, is_context auto&& ctx, It&& it, auto end) noexcept
      {
         if (bool(ctx.error)) [[unlikely]]
            return;

         skip_ws_and_comments(it, end);

         if (it == end) {
            value = {};
            return;
         }

         if (!value) {
            if (!nullable_emplace<Opts>(value, ctx)) {
               return;
            }
         }

         using V = std::remove_cvref_t<decltype(*value)>;
         from<TOML, V>::template op<Opts>(*value, ctx, it, end);
      }
   };

   template <read_supported<TOML> T, is_buffer Buffer>
   [[nodiscard]] inline error_ctx read_toml(T& value, Buffer&& buffer)
   {
      context ctx{};
      return read<opts{.format = TOML}>(value, std::forward<Buffer>(buffer), ctx);
   }

   template <read_supported<TOML> T, is_buffer Buffer>
   [[nodiscard]] inline expected<T, error_ctx> read_toml(Buffer&& buffer)
   {
      T value{};
      context ctx{};
      const error_ctx ec = read<opts{.format = TOML}>(value, std::forward<Buffer>(buffer), ctx);
      if (ec) {
         return unexpected<error_ctx>(ec);
      }
      return value;
   }

   template <read_supported<TOML> T, is_buffer Buffer>
   [[nodiscard]] inline error_ctx read_file_toml(T& value, const sv file_name, Buffer&& buffer)
   {
      context ctx{};
      ctx.current_file = file_name;

      const auto ec = file_to_buffer(buffer, ctx.current_file);

      if (bool(ec)) {
         return {0, ec};
      }

      return read<opts{.format = TOML}>(value, buffer, ctx);
   }
}
