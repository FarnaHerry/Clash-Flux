# Platform Modules

Before defining a PlatformModule, check whether the active SDK already exposes the capability through an application or window service or a presentation handle. Use those built-ins for clipboard, files, pickers, HTTP, permissions, windows, and presentation rather than registering a parallel platform abstraction.

Use a PlatformModule only for a missing non-visual capability whose implementation genuinely depends on the current platform. Do not use one for portable C++ services, embedded controls, or frame production that fits `ExternalTexture`.

## Facade and ownership

Keep the stable registration name and `ApplicationHook` wiring in the feature that owns the capability.
A reusable library or a feature with platform-selected implementations normally exposes one `InstallXxx(ApplicationContext&)` function; an app-local one-off implementation may register directly in an existing application hook instead of adding an installer abstraction.
Application UI consumes the feature's typed service or value and never opens a raw name, handles `PlatformPayload`, or retains `PlatformChannel`.
Use a window service only when one per-window Module instance is intentionally shared by unrelated consumers.
Register its factory once for the application, then open and provide an instance for each window:

```cpp
namespace {

inline constexpr char audio_player_type[] = "audio/Player";

} // namespace

void RegisterAudioPlayer(ApplicationContext& context) {
  context.RegisterPlatformModule<std::shared_ptr<AudioPlayer>>(audio_player_type, CreateAudioPlayer);
}

void InstallAudioPlayerWindow(WindowContext& context) {
  context.Provide(OpenPlatformModule<std::shared_ptr<AudioPlayer>>(audio_player_type));
}

std::shared_ptr<AudioPlayer> UseAudioPlayer() {
  return UseService<AudioPlayer>();
}
```

A component- or session-owned Module instead opens only from committed `Lifecycle` setup and releases from cleanup.
Choose one ownership path for a Module instance; do not add a second registry, lookup object, or application-visible transport facade.

## Typed C++ contract

The library defines the Module and optional Options types.
Register one exact factory from an application hook:

```cpp
context.RegisterPlatformModule<AudioPlayer, AudioPlayerOptions>(
    "audio/Player",
    [](UiWindow& ui_window, const AudioPlayerOptions& options) {
      return CreateAudioPlayer(ui_window, options);
    }
);
```

Every direct C++ factory declares exactly one host parameter: `Runtime&` for an application-scoped capability or `UiWindow&` for a window-bound capability, followed by the exact Options type when present. It returns the exact Module type.
The host reference is non-owning and must not be retained beyond its host's lifetime.
Direct C++ factories do not encode values into `PlatformPayload`.
Registration names are nonempty case-sensitive UTF-8 identities and do not require `/`.

Open a shared Module through the typed free `OpenPlatformModule<Module>(name)` operation outside composition, then optionally expose it through `ApplicationContext::Provide()` or `WindowContext::Provide()` according to its lifetime.
For component lifetime, call the same operation from committed `Lifecycle` setup and release the returned Module from cleanup. A `UiWindow&` factory requires the caller's live window context; `Runtime&` factories can open without a window.
There is no generic `UsePlatformModule`, public registry accessor, mandatory service base, or dynamic method list.

## Cross-language implementations

`PlatformPayload` and `PlatformChannel` belong only at a C++/platform-language boundary.
Keep them behind the library's typed Module facade.
A structured boundary type owns its static `Encode(const T&)` or `Decode(const PlatformPayload&)` operation; direct C++ implementations do not call those operations.
`PlatformPayload` directly supports retained `FileReference` values when a native Module needs an Android `Uri`, Apple `NSURL`, or browser `File` while preserving the original grant lifetime.
Use that capability instead of embedding a provider URI string, copying the complete file into `Bytes`, or adding a second file-access Module.
For references created from platform-library results, use the [native file-reference factories](resources-files-network.md#native-file-references).

Android currently provides `android::JavaPlatformModuleFactory<Module, Options>` for Java or Kotlin implementations.
Set `.class_name` to the Java factory class and use `.create` to wrap one framework-owned `PlatformChannel` in the library's exact Module type.
The Java implementation receives one `HuxerUIPlatformChannel.Events` emitter and uses the SDK `PlatformPayload` value; it does not declare one JNI callback per event.
`requireFileReference()` returns a retained `HuxerUIFileReference`; call `uri()` and close the wrapper only after the native consumer releases it.

Web provides `web::JavaScriptPlatformModuleFactory<Module, Options>` for a linked JavaScript structural factory.
Set `.factory` to the actual `emscripten::val` factory object, and use `.create` to wrap the framework-owned `PlatformChannel` in the library's exact Module type.
A string such as `audio_player_factory_name` may identify the module property used to obtain that object, but the adapter field remains `.factory`; it is not a factory name.
JavaScript receives immutable `Module.HuxerUI.PlatformPayload` values and one framework-owned events endpoint; it does not require inheritance or a second name registry.
For a FileReference payload, `requireFileReference()` returns a retained `HuxerUI.FileReference`; await `getFile()` and close it after use.
The Web JavaScript `PlatformPayload` bridge does not transport `ExternalTexture`; use the direct Emscripten C++ texture path when Web must provide frames rather than adding another bridge channel.

iOS and macOS expose their Objective-C/Swift contracts through the pure Objective-C Clang module `HuxerUIPlatform`.
On iOS, implement `PlatformModuleFactory` for application work or `UIKitWindowPlatformModuleFactory` for work tied to the supplied original UIViewController; macOS uses `AppKitPlatformModuleFactory`.
Each opening returns a new `PlatformModule` instance, not a singleton.
Its payload `fileReference()` accessor returns an ARC-retained `FileReference` whose `fileURL` preserves the underlying C++ access lifetime.
When an Apple Module starts asynchronous reading, playback, or writing, retain that `FileReference` alongside the player, asset, document, or provider operation until the native consumer has stopped using the resource.
Retaining only `fileURL` does not keep a security-scoped selection open after the wrapper is released.
The library's Objective-C++ application hook sets `.factory` to the actual Objective-C or Swift factory object and uses `.create` to wrap its channel in the matching typed adapter:

```cpp
ios::ObjectiveCPlatformModuleFactory<std::shared_ptr<AudioPlayer>, AudioPlayerOptions> factory{
    .factory = actual_factory,
    .create = [](PlatformChannel channel) {
      return std::make_shared<ChannelAudioPlayer>(std::move(channel));
    },
};
context.RegisterPlatformModule<std::shared_ptr<AudioPlayer>, AudioPlayerOptions>(
    "audio/Player",
    std::move(factory)
);
```

Use `macos::ObjectiveCPlatformModuleFactory` for AppKit.
The framework does not look up a class name, generate a registrant, or require the application delegate to register the factory again.
For an iOS window service, use `ios::ObjectiveCWindowPlatformModuleFactory`; application services use `ios::ObjectiveCPlatformModuleFactory` as above and do not require UI.
Direct Objective-C++ window implementations use `ios::WindowPlatformModuleFactory` or `macos::PlatformModuleFactory`; direct iOS application factories accept `Runtime&` and do not use payloads.
iOS window modules retain `presentationCoordinator(for: viewController)` from the original factory controller and use `enqueue(start:failure:)` to share FilePicker's FIFO presentation queue. Inactive windows pause admission. An unavailable window or unmanaged modal triggers the failure callback.
Run coordinator calls and callbacks on the main thread. Install native UI synchronously in `start` and return its cancellation handle. If startup leaves no UI, call `finished` synchronously before returning `nil`.
Canceling a queued request prevents it from starting. Active cancellation holds the slot until the UI is gone and `finished` runs. Call it from the programmatic dismissal completion or from `presentationControllerDidDismiss` for interactive dismissal. Window teardown closes the coordinator permanently.
Keep provider work cancellation separate from presentation completion. Use a UI Task scope for picker work and hand acquired `FileReference` values to application work afterward. See [File picker](resources-files-network.md#file-picker) for the public picker contract.

`PlatformChannel::Invoke` returns a request identity before scheduling the platform invocation on the owning UI thread.
Use `Invoke<Result>(method, completion)` when both the argument and result are Null; the typed C++ completion receives `PlatformResult<std::monostate>`.
Results and events return asynchronously through that dispatcher.
PlatformChannel event subscriptions remain void notifications even though the generic `Event` type supports synchronous result signatures for local code and PlatformView delegate decisions.
Keep Module request results on `Invoke`; do not model RPC as a result-returning event.
`Cancel` and `Close` invalidate C++ delivery immediately; queued invocations are skipped, in-flight cancellation runs before disposal, and late results or events are ignored.
When adapting Invoke to a Task with [AwaitCallback](fundamentals.md#callback-integration), provide a separate completion or failure path for facade/channel closure while the Task remains alive. Close drops pending callbacks rather than delivering a result; wrapping Invoke alone can leave the Task suspended. The SDK has no `PlatformChannel::InvokeAsync()` convenience.
The channel is a reusable transport convenience, not a PlatformModule base class or the Module API exposed to application UI.
Apple factory creation, invocation, cancellation, and disposal run on the UIKit or AppKit main thread; results and events may originate on any queue and resume through the owning surface dispatcher.

## Review points

- one explicit application-hook registration and no platform-host registration path;
- stable name and registration owned by one feature boundary, with an installer only when it adds value;
- application UI sees only the typed domain facade;
- exact Module and Options types on the direct C++ path;
- payload conversion confined to an actual language boundary;
- deterministic ownership, cancellation, and disposal;
- no string methods, payload maps, or channels exposed through application components;
- no PlatformModule where portable C++ already owns the capability.
