#pragma once

#if defined(__OBJC__)
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class HUXExternalTexture;
@class UNNotificationContent;

/// Retains a C++ FileReference while exposing its native file URL to UIKit libraries.
NS_SWIFT_NAME(FileReference)
@interface HUXFileReference : NSObject

@property(nonatomic, readonly) NSURL* fileURL;

/// Copies a readable ordinary file into SDK-owned temporary storage and returns a read-only capability.
/// The copy finishes before returning, including when url is valid only inside a provider callback. May block;
/// background queues are supported. The SDK balances only security-scoped access it acquires for this copy.
/// The last reference, stream, or pending operation releases the copy; retaining fileURL alone does not retain it.
/// @param url A file URL whose contents remain readable throughout this call.
/// @param error Receives the access or copy error on failure; partial temporary contents are removed.
/// @return A retained payload-compatible reference, or nil on failure. Does not modify or take ownership of url.
+ (nullable instancetype)copyFromFileURL:(NSURL*)url error:(NSError* _Nullable* _Nullable)error
    NS_SWIFT_NAME(copy(from:));

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

/// Retains address-stable memory without taking a byte snapshot.
/// The owner must keep the pointer valid; it may be released on the last reader's thread.
/// Synchronize producer writes with readers. Never retain pointers borrowed from temporary Swift Data storage.
NS_SWIFT_NAME(BufferReference)
@interface HUXBufferReference : NSObject

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)initWithBytes:(const void* _Nullable)bytes length:(NSUInteger)length owner:(id)owner
    NS_SWIFT_NAME(init(bytes:length:owner:));

/// Borrows read-only memory for the callback only. The pointer must not escape.
/// @param reader Synchronous reader; retain the reference itself for asynchronous work.
- (void)withUnsafeBytes:(void (^)(const void* _Nullable bytes, NSUInteger length))reader
    NS_SWIFT_NAME(withUnsafeBytes(_:));

/// Returns a retained subrange without copying.
/// @param offset Byte offset relative to this reference.
/// @param length Byte count; an out-of-range slice raises NSInvalidArgumentException.
- (HUXBufferReference*)sliceWithOffset:(NSUInteger)offset length:(NSUInteger)length
    NS_SWIFT_NAME(slice(offset:length:));

@end

typedef NS_ENUM(NSInteger, HUXPlatformPayloadKind) {
  HUXPlatformPayloadKindNull,
  HUXPlatformPayloadKindBoolean,
  HUXPlatformPayloadKindInteger,
  HUXPlatformPayloadKindDouble,
  HUXPlatformPayloadKindString,
  HUXPlatformPayloadKindBytes,
  HUXPlatformPayloadKindList,
  HUXPlatformPayloadKindObject,
  HUXPlatformPayloadKindExternalTexture,
  HUXPlatformPayloadKindFileReference,
  HUXPlatformPayloadKindBufferReference,
} NS_SWIFT_NAME(PlatformPayload.Kind);

NS_SWIFT_NAME(PlatformPayload)
@interface HUXPlatformPayload : NSObject

@property(nonatomic, readonly) HUXPlatformPayloadKind kind;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

+ (instancetype)nullValue NS_SWIFT_NAME(null());
+ (instancetype)booleanValue:(BOOL)value NS_SWIFT_NAME(boolean(_:));
+ (instancetype)integerValue:(int64_t)value NS_SWIFT_NAME(integer(_:));
+ (instancetype)doubleValue:(double)value NS_SWIFT_NAME(double(_:));
+ (instancetype)stringValue:(NSString*)value NS_SWIFT_NAME(string(_:));
+ (instancetype)bytesValue:(NSData*)value NS_SWIFT_NAME(bytes(_:));
+ (instancetype)listValue:(NSArray<HUXPlatformPayload*>*)value NS_SWIFT_NAME(list(_:));
+ (instancetype)objectValue:(NSDictionary<NSString*, HUXPlatformPayload*>*)value NS_SWIFT_NAME(object(_:));
+ (instancetype)externalTextureValue:(HUXExternalTexture*)texture NS_SWIFT_NAME(externalTexture(_:));
+ (instancetype)fileReferenceValue:(HUXFileReference*)reference NS_SWIFT_NAME(fileReference(_:));
+ (instancetype)bufferReferenceValue:(HUXBufferReference*)reference NS_SWIFT_NAME(bufferReference(_:));

- (BOOL)booleanValue NS_SWIFT_NAME(boolean());
- (int64_t)integerValue NS_SWIFT_NAME(integer());
- (double)doubleValue NS_SWIFT_NAME(double());
- (NSString*)stringValue NS_SWIFT_NAME(string());
- (NSData*)bytesValue NS_SWIFT_NAME(bytes());
- (HUXExternalTexture*)externalTextureValue NS_SWIFT_NAME(externalTexture());
- (HUXFileReference*)fileReferenceValue NS_SWIFT_NAME(fileReference());
- (HUXBufferReference*)bufferReferenceValue NS_SWIFT_NAME(bufferReference());
- (HUXPlatformPayload*)field:(NSString*)name NS_SWIFT_NAME(field(_:));
- (HUXPlatformPayload*)elementAtIndex:(NSUInteger)index NS_SWIFT_NAME(element(at:));
- (void)validateFields:(NSSet<NSString*>*)fields NS_SWIFT_NAME(validate(fields:));

@end

/// Reads the submitted application data snapshot in a Notification Content Extension.
/// @param content The notification content delivered to the extension.
/// @return The decoded value, Null when absent, or nil for malformed or oversized data.
FOUNDATION_EXPORT HUXPlatformPayload* _Nullable HUXGetLocalNotificationData(UNNotificationContent* content)
    NS_SWIFT_NAME(localNotificationData(_:));

NS_SWIFT_NAME(PlatformEventEmitter)
@protocol HUXPlatformEventEmitter <NSObject>
- (nullable HUXPlatformPayload*)emit:(NSString*)event payload:(HUXPlatformPayload*)payload;
@end

NS_SWIFT_NAME(PlatformResult)
@protocol HUXPlatformResult <NSObject>
- (void)complete:(HUXPlatformPayload*)value;
- (void)failWithCode:(NSString*)code
             message:(NSString*)message
             details:(HUXPlatformPayload*)details;
@end

NS_SWIFT_NAME(PlatformCancellation)
@protocol HUXPlatformCancellation <NSObject>
- (void)cancel;
@end

NS_SWIFT_NAME(PlatformModule)
@protocol HUXPlatformModule <NSObject>
- (nullable id<HUXPlatformCancellation>)invoke:(NSString*)method
                                      arguments:(HUXPlatformPayload*)arguments
                                         result:(id<HUXPlatformResult>)result;
- (void)dispose;
@end

/// Creates one application-bound instance per OpenPlatformModule call, without requiring a window.
NS_SWIFT_NAME(PlatformModuleFactory)
@protocol HUXPlatformModuleFactory <NSObject>
- (id<HUXPlatformModule>)createWithOptions:(HUXPlatformPayload*)options
                                   events:(id<HUXPlatformEventEmitter>)events
    NS_SWIFT_NAME(create(options:events:));
@end

/// Creates an instance bound to the supplied original HuxerUI window.
NS_SWIFT_NAME(UIKitWindowPlatformModuleFactory)
@protocol HUXUIKitWindowPlatformModuleFactory <NSObject>
- (id<HUXPlatformModule>)createWithViewController:(UIViewController*)viewController
                                          options:(HUXPlatformPayload*)options
                                           events:(id<HUXPlatformEventEmitter>)events;
@end

/// Serializes native presentations for one original HuxerUI window. All operations run on the main thread.
/// Pauses admission while the window is inactive. Unmanaged modal UI fails admission instead of being covered.
NS_SWIFT_NAME(PresentationCoordinator)
@interface HUXPresentationCoordinator : NSObject
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

/// Enqueues a presentation and returns its cancellation handle before start can run.
/// start installs UI synchronously and returns native cancellation. It may return nil only after calling finished.
/// Call finished exactly when UI is absent: after dismiss completion, interactive dismissal, or failed startup.
/// Canceling a queued request prevents start; canceling active UI invokes native cancellation once and keeps its slot
/// until finished. Duplicate or late finished calls are harmless. Media processing may continue after releasing UI.
/// failure reports host closure, unavailable/busy presentation, or invalid startup, but not explicit cancellation.
/// Window closure fails pending requests and requests active cleanup; retained coordinators never bind to another host.
- (id<HUXPlatformCancellation>)enqueueWithStart:
    (id<HUXPlatformCancellation> _Nullable (^)(UIViewController* presenter, void (^finished)(void)))start
    failure:(void (^)(NSError* error))failure NS_SWIFT_NAME(enqueue(start:failure:));
@end

/// Returns the coordinator for the exact HuxerUI controller supplied to a window factory, on the main thread.
/// Raises NSInvalidArgumentException for a controller not owned by HuxerUI. Retain the result for delayed work.
FOUNDATION_EXPORT HUXPresentationCoordinator* HUXGetPresentationCoordinator(UIViewController* owner)
    NS_SWIFT_NAME(presentationCoordinator(for:));

NS_SWIFT_NAME(UIKitPlatformView)
@protocol HUXUIKitPlatformView <NSObject>
@property(nonatomic, readonly) UIView* view;
@optional
- (void)updateWithProperties:(HUXPlatformPayload*)properties;
- (nullable id<HUXPlatformCancellation>)invoke:(NSString*)method
                                      arguments:(HUXPlatformPayload*)arguments
                                         result:(id<HUXPlatformResult>)result;
@required
- (void)dispose;
@end

NS_SWIFT_NAME(UIKitPlatformViewFactory)
@protocol HUXUIKitPlatformViewFactory <NSObject>
- (id<HUXUIKitPlatformView>)createWithViewController:(UIViewController*)viewController
                                          properties:(HUXPlatformPayload*)properties
                                              events:(id<HUXPlatformEventEmitter>)events;
@end

NS_ASSUME_NONNULL_END
#endif

#if defined(__cplusplus)
#if defined(__OBJC__)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wnullability-completeness"
#endif
#include <concepts>
#include <functional>
#include <memory>
#include <stdexcept>
#include <utility>

#include <huxerui/platform_registry.h>

#if defined(__OBJC__)
@class UIView;
@class UIViewController;
#else
class UIView;
class UIViewController;
#endif

namespace huxerui::ios {

/// Describes the UIKit lifecycle of one registered PlatformView type.
///
/// Properties is the complete controlled value supplied by `PlatformView(name, properties)`. Instance is arbitrary
/// library-owned retained state and commonly stores the UIView plus delegates, targets, and event resources. Controller
/// is optional and connects a strongly typed C++ command facade to the mounted instance.
///
/// `create` and `view` are required. `create` receives the owning UIViewController, and `view` is called once to obtain
/// the stable UIView retained by Instance. When Properties is not void, `update` must apply later property revisions.
/// When Controller is not void, both `connect` and `disconnect` are required. `dispose` is optional and runs after
/// Controller disconnection. Callbacks execute on the UIKit main thread.
///
/// Example:
/// @code
/// ios::PlatformViewFactory<MapProperties, MapInstance, MapController> factory{
///     .create = CreateMap,
///     .view = [](const std::shared_ptr<MapInstance>& instance) { return instance->view; },
///     .update = UpdateMap,
///     .dispose = DisposeMap,
///     .connect = ConnectMapController,
///     .disconnect = DisconnectMapController,
/// };
/// context.RegisterPlatformView<MapProperties, MapController>("Map", std::move(factory));
/// @endcode
///
/// @tparam Properties Controlled declarative state, or void when the View has no properties.
/// @tparam Instance Retained C++ or Objective-C++ state whose shared lifetime covers the mounted UIView.
/// @tparam Controller Optional strongly typed command endpoint connected for the mounted View.
template <class Properties, class Instance, class Controller = void> struct PlatformViewFactory;
template <class Module, class Options = void> struct WindowPlatformModuleFactory;

#if defined(__OBJC__)
template <class Module, class Options = void> struct ObjectiveCPlatformModuleFactory;
template <class Module, class Options = void> struct ObjectiveCWindowPlatformModuleFactory;
template <class Properties, class Controller = void> struct ObjectiveCPlatformViewFactory;
#endif

namespace detail {

/// Type-erased UIKit factory consumed by the iOS PlatformView host.
struct UIKitViewFactory {
  std::function<std::shared_ptr<void>(UIViewController*, const PlatformValue&, PlatformEventEmitter)> create;
  std::function<UIView*(const std::shared_ptr<void>&)> view;
  std::function<void(const std::shared_ptr<void>&, const PlatformValue&)> update;
  std::function<void(const std::shared_ptr<void>&)> dispose;
  std::function<void(const std::shared_ptr<void>&, const PlatformValue&)> connect;
  std::function<void(const std::shared_ptr<void>&, const PlatformValue&)> disconnect;
};

UIViewController* GetUIKitViewController(UiWindow& ui_window);

#if defined(__OBJC__)
class ObjectiveCPlatformViewInstance;

PlatformChannel CreateObjectiveCPlatformModule(Runtime& runtime, id<HUXPlatformModuleFactory> factory,
                                               PlatformPayload options);
PlatformChannel CreateObjectiveCWindowPlatformModule(UiWindow& ui_window, UIViewController* owner,
                                                     id<HUXUIKitWindowPlatformModuleFactory> factory,
                                                     PlatformPayload options);
std::shared_ptr<ObjectiveCPlatformViewInstance>
CreateObjectiveCPlatformView(UiWindow& ui_window, UIViewController* owner,
                             id<HUXUIKitPlatformViewFactory> factory, PlatformPayload properties,
                             PlatformEventEmitter events, bool update_required, bool channel_required);
UIView* GetObjectiveCPlatformView(const std::shared_ptr<ObjectiveCPlatformViewInstance>& instance);
void UpdateObjectiveCPlatformView(const std::shared_ptr<ObjectiveCPlatformViewInstance>& instance,
                                  PlatformPayload properties);
void DisposeObjectiveCPlatformView(const std::shared_ptr<ObjectiveCPlatformViewInstance>& instance) noexcept;
PlatformChannel GetObjectiveCPlatformViewChannel(const std::shared_ptr<ObjectiveCPlatformViewInstance>& instance);

template <class Properties> PlatformPayload EncodeObjectiveCPlatformViewProperties(const PlatformValue& value) {
  if constexpr (std::same_as<Properties, void>) {
    return {};
  } else {
    static_assert(huxerui::detail::PlatformPayloadEncodable<Properties>);
    return huxerui::detail::EncodePlatformValue(value.Get<Properties>());
  }
}

template <class Properties, class Controller>
huxerui::detail::PlatformViewFactoryRegistration
EraseObjectiveCPlatformViewFactory(ios::ObjectiveCPlatformViewFactory<Properties, Controller> source_value,
                                   UiWindow& ui_window) {
  auto source =
      std::make_shared<ios::ObjectiveCPlatformViewFactory<Properties, Controller>>(std::move(source_value));
  auto factory = std::make_shared<UIKitViewFactory>();
  factory->create = [source, ui_window = &ui_window](UIViewController* owner, const PlatformValue& properties,
                                               PlatformEventEmitter events) {
    return std::static_pointer_cast<void>(CreateObjectiveCPlatformView(
        *ui_window, owner, source->factory, EncodeObjectiveCPlatformViewProperties<Properties>(properties),
        std::move(events), !std::same_as<Properties, void>, !std::same_as<Controller, void>));
  };
  factory->view = [](const std::shared_ptr<void>& instance) {
    return GetObjectiveCPlatformView(std::static_pointer_cast<ObjectiveCPlatformViewInstance>(instance));
  };
  if constexpr (!std::same_as<Properties, void>) {
    factory->update = [](const std::shared_ptr<void>& instance, const PlatformValue& properties) {
      UpdateObjectiveCPlatformView(std::static_pointer_cast<ObjectiveCPlatformViewInstance>(instance),
                                   EncodeObjectiveCPlatformViewProperties<Properties>(properties));
    };
  }
  factory->dispose = [](const std::shared_ptr<void>& instance) {
    DisposeObjectiveCPlatformView(std::static_pointer_cast<ObjectiveCPlatformViewInstance>(instance));
  };
  if constexpr (!std::same_as<Controller, void>) {
    factory->connect = [source](const std::shared_ptr<void>& instance, const PlatformValue& controller) {
      if (!source->connect) {
        throw std::logic_error("HuxerUI iOS Objective-C PlatformView factory must provide connect");
      }
      source->connect(controller.Get<Controller>(),
                      GetObjectiveCPlatformViewChannel(
                          std::static_pointer_cast<ObjectiveCPlatformViewInstance>(instance)));
    };
    factory->disconnect = [source](const std::shared_ptr<void>&, const PlatformValue& controller) {
      if (!source->disconnect) {
        throw std::logic_error("HuxerUI iOS Objective-C PlatformView factory must provide disconnect");
      }
      source->disconnect(controller.Get<Controller>());
    };
  }
  return huxerui::detail::MakePlatformViewFactoryRegistration(std::move(factory));
}
#endif

template <class Properties, class Instance, class Controller>
huxerui::detail::PlatformViewFactoryRegistration
ErasePlatformViewFactory(ios::PlatformViewFactory<Properties, Instance, Controller> source_value) {
  auto source = std::make_shared<ios::PlatformViewFactory<Properties, Instance, Controller>>(std::move(source_value));
  auto factory = std::make_shared<UIKitViewFactory>();
  if (source->create) {
    factory->create = [source](UIViewController* owner, const PlatformValue& properties, PlatformEventEmitter events) {
      if constexpr (std::same_as<Properties, void>) {
        return std::static_pointer_cast<void>(source->create(owner, std::move(events)));
      } else {
        return std::static_pointer_cast<void>(source->create(owner, properties.Get<Properties>(), std::move(events)));
      }
    };
  }
  if (source->view) {
    factory->view = [source](const std::shared_ptr<void>& instance) {
      return source->view(std::static_pointer_cast<Instance>(instance));
    };
  }
  if constexpr (!std::same_as<Properties, void>) {
    if (source->update) {
      factory->update = [source](const std::shared_ptr<void>& instance, const PlatformValue& properties) {
        source->update(*std::static_pointer_cast<Instance>(instance), properties.Get<Properties>());
      };
    }
  }
  if (source->dispose) {
    factory->dispose = [source](const std::shared_ptr<void>& instance) {
      source->dispose(*std::static_pointer_cast<Instance>(instance));
    };
  }
  if constexpr (!std::same_as<Controller, void>) {
    if (source->connect) {
      factory->connect = [source](const std::shared_ptr<void>& instance, const PlatformValue& controller) {
        source->connect(*std::static_pointer_cast<Instance>(instance), controller.Get<Controller>());
      };
    }
    if (source->disconnect) {
      factory->disconnect = [source](const std::shared_ptr<void>& instance, const PlatformValue& controller) {
        source->disconnect(*std::static_pointer_cast<Instance>(instance), controller.Get<Controller>());
      };
    }
  }
  return huxerui::detail::MakePlatformViewFactoryRegistration(std::move(factory));
}

} // namespace detail

/// Adapts a direct Objective-C++ PlatformModule factory to the platform-neutral registry callable contract.
template <class Module> struct WindowPlatformModuleFactory<Module, void> {
  std::function<Module(UiWindow&, UIViewController*)> create;

  Module operator()(UiWindow& ui_window) {
    if (!create) {
      throw std::logic_error("HuxerUI iOS PlatformModule factory must provide create");
    }
    return create(ui_window, detail::GetUIKitViewController(ui_window));
  }
};

template <class Module, class Options> struct WindowPlatformModuleFactory {
  std::function<Module(UiWindow&, UIViewController*, const Options&)> create;

  Module operator()(UiWindow& ui_window, const Options& options) {
    if (!create) {
      throw std::logic_error("HuxerUI iOS PlatformModule factory must provide create");
    }
    return create(ui_window, detail::GetUIKitViewController(ui_window), options);
  }
};

#if defined(__OBJC__)
/// Creates an application-bound Objective-C or Swift instance without requiring a UiWindow.
/// The factory object creates the platform instance; create wraps its framework-owned PlatformChannel in Module.
template <class Module> struct ObjectiveCPlatformModuleFactory<Module, void> {
  __strong id<HUXPlatformModuleFactory> factory = nil;
  std::function<Module(PlatformChannel)> create;

  Module operator()(Runtime& runtime) {
    if (factory == nil || !create) {
      throw std::logic_error("HuxerUI iOS Objective-C PlatformModule factory is incomplete");
    }
    PlatformChannel channel =
        detail::CreateObjectiveCPlatformModule(runtime, factory, {});
    try {
      return create(channel);
    } catch (...) {
      channel.Close();
      throw;
    }
  }
};

template <class Module, class Options> struct ObjectiveCPlatformModuleFactory {
  static_assert(huxerui::detail::PlatformPayloadEncodable<Options>);

  __strong id<HUXPlatformModuleFactory> factory = nil;
  std::function<Module(PlatformChannel)> create;

  Module operator()(Runtime& runtime, const Options& options) {
    if (factory == nil || !create) {
      throw std::logic_error("HuxerUI iOS Objective-C PlatformModule factory is incomplete");
    }
    PlatformChannel channel = detail::CreateObjectiveCPlatformModule(
        runtime, factory, huxerui::detail::EncodePlatformValue(options));
    try {
      return create(channel);
    } catch (...) {
      channel.Close();
      throw;
    }
  }
};

/// Creates a window-bound Objective-C or Swift instance and wraps its channel in a strongly typed Module.
/// The factory object creates the platform instance; create wraps its framework-owned PlatformChannel in Module.
template <class Module> struct ObjectiveCWindowPlatformModuleFactory<Module, void> {
  __strong id<HUXUIKitWindowPlatformModuleFactory> factory = nil;
  std::function<Module(PlatformChannel)> create;

  Module operator()(UiWindow& ui_window) {
    if (factory == nil || !create) {
      throw std::logic_error("HuxerUI iOS Objective-C PlatformModule factory is incomplete");
    }
    PlatformChannel channel =
        detail::CreateObjectiveCWindowPlatformModule(ui_window, detail::GetUIKitViewController(ui_window), factory, {});
    try {
      return create(channel);
    } catch (...) {
      channel.Close();
      throw;
    }
  }
};

template <class Module, class Options> struct ObjectiveCWindowPlatformModuleFactory {
  static_assert(huxerui::detail::PlatformPayloadEncodable<Options>);

  __strong id<HUXUIKitWindowPlatformModuleFactory> factory = nil;
  std::function<Module(PlatformChannel)> create;

  Module operator()(UiWindow& ui_window, const Options& options) {
    if (factory == nil || !create) {
      throw std::logic_error("HuxerUI iOS Objective-C PlatformModule factory is incomplete");
    }
    PlatformChannel channel = detail::CreateObjectiveCWindowPlatformModule(
        ui_window, detail::GetUIKitViewController(ui_window), factory, huxerui::detail::EncodePlatformValue(options));
    try {
      return create(channel);
    } catch (...) {
      channel.Close();
      throw;
    }
  }
};

template <class Properties> struct ObjectiveCPlatformViewFactory<Properties, void> {
  __strong id<HUXUIKitPlatformViewFactory> factory = nil;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow& ui_window) && {
    return detail::EraseObjectiveCPlatformViewFactory(std::move(*this), ui_window);
  }
  friend class huxerui::detail::PlatformRegistry;
};

template <class Properties, class Controller> struct ObjectiveCPlatformViewFactory {
  __strong id<HUXUIKitPlatformViewFactory> factory = nil;
  std::function<void(const Controller&, PlatformChannel)> connect;
  std::function<void(const Controller&)> disconnect;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow& ui_window) && {
    return detail::EraseObjectiveCPlatformViewFactory(std::move(*this), ui_window);
  }
  friend class huxerui::detail::PlatformRegistry;
};
#endif

/// UIKit PlatformView factory without declarative Properties or a Controller.
template <class Instance> struct PlatformViewFactory<void, Instance, void> {
  std::function<std::shared_ptr<Instance>(UIViewController*, PlatformEventEmitter)> create;
  std::function<UIView*(const std::shared_ptr<Instance>&)> view;
  std::function<void(Instance&)> dispose;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow&) && {
    return detail::ErasePlatformViewFactory(std::move(*this));
  }
  friend class huxerui::detail::PlatformRegistry;
};

/// UIKit PlatformView factory with a Controller and no declarative Properties.
template <class Instance, class Controller> struct PlatformViewFactory<void, Instance, Controller> {
  std::function<std::shared_ptr<Instance>(UIViewController*, PlatformEventEmitter)> create;
  std::function<UIView*(const std::shared_ptr<Instance>&)> view;
  std::function<void(Instance&)> dispose;
  std::function<void(Instance&, const Controller&)> connect;
  std::function<void(Instance&, const Controller&)> disconnect;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow&) && {
    return detail::ErasePlatformViewFactory(std::move(*this));
  }
  friend class huxerui::detail::PlatformRegistry;
};

/// UIKit PlatformView factory with controlled Properties and no Controller.
template <class Properties, class Instance> struct PlatformViewFactory<Properties, Instance, void> {
  std::function<std::shared_ptr<Instance>(UIViewController*, const Properties&, PlatformEventEmitter)> create;
  std::function<UIView*(const std::shared_ptr<Instance>&)> view;
  std::function<void(Instance&, const Properties&)> update;
  std::function<void(Instance&)> dispose;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow&) && {
    return detail::ErasePlatformViewFactory(std::move(*this));
  }
  friend class huxerui::detail::PlatformRegistry;
};

/// UIKit PlatformView factory with controlled Properties and a Controller.
template <class Properties, class Instance, class Controller> struct PlatformViewFactory {
  std::function<std::shared_ptr<Instance>(UIViewController*, const Properties&, PlatformEventEmitter)> create;
  std::function<UIView*(const std::shared_ptr<Instance>&)> view;
  std::function<void(Instance&, const Properties&)> update;
  std::function<void(Instance&)> dispose;
  std::function<void(Instance&, const Controller&)> connect;
  std::function<void(Instance&, const Controller&)> disconnect;

private:
  huxerui::detail::PlatformViewFactoryRegistration Erase(UiWindow&) && {
    return detail::ErasePlatformViewFactory(std::move(*this));
  }
  friend class huxerui::detail::PlatformRegistry;
};

} // namespace huxerui::ios

#if defined(__OBJC__)
#pragma clang diagnostic pop
#endif
#endif
